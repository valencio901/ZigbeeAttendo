import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:http/http.dart' as http;
import 'package:mockito/mockito.dart';
import 'dart:convert';
import 'package:aats_app/register.dart';

// Mock HTTP client
class MockClient extends Mock implements http.Client {}

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group('RegisterPage Tests', () {
    // 📌 **Page Load Speed Test**
    testWidgets('RegisterPage should load within acceptable time',
        (WidgetTester tester) async {
      final stopwatch = Stopwatch()..start();

      await tester.pumpWidget(MaterialApp(
        home: RegisterPage(),
      ));
      await tester.pumpAndSettle(); // Wait until all animations finish

      stopwatch.stop();
      print('Page load time: ${stopwatch.elapsedMilliseconds} ms');

      // Ensure the page loads within 3 seconds
      expect(stopwatch.elapsedMilliseconds, lessThan(3000),
          reason: 'Page should load within 3 seconds');
    });

    // 📌 **UI Stress Test: Form Filling and Button Click**
    testWidgets('Stress test: Form filling and registration button click',
        (WidgetTester tester) async {
      await tester.pumpWidget(MaterialApp(
        home: RegisterPage(),
      ));
      await tester.pumpAndSettle();

      // Enter data into the text fields
      await tester.enterText(find.byType(TextField).at(0), '1234'); // Roll No
      await tester.enterText(find.byType(TextField).at(1), 'John Doe'); // Name
      await tester.enterText(find.byType(TextField).at(2), 'FYBCA A'); // Class
      await tester.enterText(
          find.byType(TextField).at(3), 'Room 101'); // Classroom
      await tester.enterText(
          find.byType(TextField).at(4), 'XYZ College'); // College
      await tester.enterText(
          find.byType(TextField).at(5), 'password123'); // Password

      // Tap on the register button
      await tester.tap(find.text('Register'));
      await tester.pumpAndSettle();

      // Verify that the dialog appears after registration (success)
      expect(find.text('Registration successful'), findsOneWidget);

      print("UI stress test passed: Form filled and submission handled.");
    });

    // 📌 **API Test (Mocking HTTP Request for Registration)**
    test('Test API submission and response handling (mocked)', () async {
      final client = MockClient();
      when(client.post(any, body: anyNamed('body')))
          .thenAnswer((_) async => http.Response('{"status": "success"}', 200));

      const String url =
          'https://8892-2409-4042-6e98-bbe2-1915-272e-c03e-d5cc.ngrok-free.app/student_register.php';

      final response = await client.post(Uri.parse(url), body: {
        'rollno': '1234',
        'name': 'John Doe',
        'password': 'password123',
        'class': 'FYBCA A',
        'classroom': 'Room 101',
        'college': 'XYZ College',
      });

      expect(response.statusCode, 200);
      expect(json.decode(response.body)['status'], 'success');

      print("API test passed: Successfully mocked API response.");
    });

    // 📌 **Performance Test: Form Submission Speed**
    testWidgets('Form submission should respond within acceptable time',
        (WidgetTester tester) async {
      final stopwatch = Stopwatch()..start();

      await tester.pumpWidget(MaterialApp(
        home: RegisterPage(),
      ));
      await tester.pumpAndSettle();

      // Enter data into the text fields
      await tester.enterText(find.byType(TextField).at(0), '1234'); // Roll No
      await tester.enterText(find.byType(TextField).at(1), 'John Doe'); // Name
      await tester.enterText(find.byType(TextField).at(2), 'FYBCA A'); // Class
      await tester.enterText(
          find.byType(TextField).at(3), 'Room 101'); // Classroom
      await tester.enterText(
          find.byType(TextField).at(4), 'XYZ College'); // College
      await tester.enterText(
          find.byType(TextField).at(5), 'password123'); // Password

      // Tap on the register button
      await tester.tap(find.text('Register'));
      await tester.pumpAndSettle();

      stopwatch.stop();
      print('Form submission time: ${stopwatch.elapsedMilliseconds} ms');

      // Ensure that the form submission completes in less than 2 seconds
      expect(stopwatch.elapsedMilliseconds, lessThan(2000),
          reason: 'Form submission should be quick');
    });

    // 📌 **Error Handling Test: API Failure**
    testWidgets('Test error handling for API failure',
        (WidgetTester tester) async {
      final client = MockClient();
      when(client.post(any, body: anyNamed('body')))
          .thenAnswer((_) async => http.Response('{"status": "error"}', 400));

      const String url =
          'https://8892-2409-4042-6e98-bbe2-1915-272e-c03e-d5cc.ngrok-free.app/student_register.php';

      final response = await client.post(Uri.parse(url), body: {
        'rollno': '1234',
        'name': 'John Doe',
        'password': 'password123',
        'class': 'FYBCA A',
        'classroom': 'Room 101',
        'college': 'XYZ College',
      });

      // Simulate error response handling in your UI (showing a message to the user)
      expect(response.statusCode, 400);
      expect(json.decode(response.body)['status'], 'error');

      print("Error handling test passed: Handled API failure.");
    });
  });
}
