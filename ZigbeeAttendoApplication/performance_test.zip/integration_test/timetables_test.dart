import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:mockito/mockito.dart';
import 'package:aats_app/TiimeTables.dart';

// ✅ Mocking HTTP Client
class MockClient extends Mock implements http.Client {}

void main() {
  group('📌 TimetablePage Tests', () {
    late MockClient mockClient;

    setUp(() {
      mockClient = MockClient();
    });

    // 📌 **UI Test: Page Renders Correctly**
    testWidgets('✅ TimetablePage UI elements should be rendered properly',
        (WidgetTester tester) async {
      await tester
          .pumpWidget(MaterialApp(home: TimetablePage(className: "TYBCA_A")));

      expect(find.text("TIMETABLE FOR TYBCA_A"), findsOneWidget);
      expect(find.byType(CircularProgressIndicator), findsOneWidget);
    });

    // 📌 **API Test: Fetch Successful**
    testWidgets('✅ Timetable fetch success should display data',
        (WidgetTester tester) async {
      when(mockClient.post(any, body: anyNamed('body')))
          .thenAnswer((_) async => http.Response(
              jsonEncode({
                "Monday": [
                  {
                    "id": "1",
                    "lecture": "Mathematics",
                    "start_time": "10:00 AM",
                    "end_time": "11:00 AM",
                    "teacher": "Mr. Smith",
                    "classroom": "101"
                  }
                ]
              }),
              200));

      await tester
          .pumpWidget(MaterialApp(home: TimetablePage(className: "TYBCA_A")));
      await tester.pumpAndSettle();

      // ✅ Ensure data is displayed
      expect(find.text("Monday"), findsOneWidget);
      expect(find.text("Mathematics"), findsOneWidget);
      expect(find.text("Mr. Smith"), findsOneWidget);
      expect(find.text("10:00 AM"), findsOneWidget);
      expect(find.text("101"), findsOneWidget);
    });

    // 📌 **API Test: No Timetable Records**
    testWidgets('✅ No timetable records should show a proper message',
        (WidgetTester tester) async {
      when(mockClient.post(any, body: anyNamed('body')))
          .thenAnswer((_) async => http.Response(jsonEncode({}), 200));

      await tester
          .pumpWidget(MaterialApp(home: TimetablePage(className: "TYBCA_A")));
      await tester.pumpAndSettle();

      // ✅ Verify "No records found" message
      expect(find.text("No timetable found"), findsOneWidget);
    });

    // 📌 **API Test: Update Timetable Entry**
    testWidgets('✅ Updating a timetable entry should refresh UI',
        (WidgetTester tester) async {
      when(mockClient.post(any, body: anyNamed('body')))
          .thenAnswer((_) async => http.Response(
              jsonEncode({
                "Monday": [
                  {
                    "id": "1",
                    "lecture": "Mathematics",
                    "start_time": "10:00 AM",
                    "end_time": "11:00 AM",
                    "teacher": "Mr. Smith",
                    "classroom": "101"
                  }
                ]
              }),
              200));

      await tester
          .pumpWidget(MaterialApp(home: TimetablePage(className: "TYBCA_A")));
      await tester.pumpAndSettle();

      // ✅ Open Update Dialog
      await tester.tap(find.byIcon(Icons.edit).first);
      await tester.pumpAndSettle();

      // ✅ Change text and submit
      await tester.enterText(find.byType(TextField).first, "Physics");
      await tester.tap(find.text("Save"));
      await tester.pumpAndSettle();

      // ✅ Verify UI updates with new data
      expect(find.text("Physics"), findsOneWidget);
    });

    // 📌 **API Test: Delete Timetable Entry**
    testWidgets('✅ Deleting a timetable entry should refresh UI',
        (WidgetTester tester) async {
      when(mockClient.post(any, body: anyNamed('body')))
          .thenAnswer((_) async => http.Response(
              jsonEncode({
                "Monday": [
                  {
                    "id": "1",
                    "lecture": "Mathematics",
                    "start_time": "10:00 AM",
                    "end_time": "11:00 AM",
                    "teacher": "Mr. Smith",
                    "classroom": "101"
                  }
                ]
              }),
              200));

      await tester
          .pumpWidget(MaterialApp(home: TimetablePage(className: "TYBCA_A")));
      await tester.pumpAndSettle();

      // ✅ Click Delete
      await tester.tap(find.byIcon(Icons.delete).first);
      await tester.pumpAndSettle();

      // ✅ Verify UI updates with no data
      expect(find.text("Mathematics"), findsNothing);
    });

    // 📌 **Performance Test: Fetching Timetable Data**
    testWidgets('✅ Fetching timetable should respond within 2 seconds',
        (WidgetTester tester) async {
      final stopwatch = Stopwatch()..start();

      when(mockClient.post(any, body: anyNamed('body')))
          .thenAnswer((_) async => http.Response(
              jsonEncode({
                "Monday": [
                  {
                    "id": "1",
                    "lecture": "Mathematics",
                    "start_time": "10:00 AM",
                    "end_time": "11:00 AM",
                    "teacher": "Mr. Smith",
                    "classroom": "101"
                  }
                ]
              }),
              200));

      await tester
          .pumpWidget(MaterialApp(home: TimetablePage(className: "TYBCA_A")));
      await tester.pumpAndSettle();

      stopwatch.stop();
      print(
          '⏱️ Fetching timetable response time: ${stopwatch.elapsedMilliseconds} ms');

      // ✅ Ensure API responds within 2 seconds
      expect(stopwatch.elapsedMilliseconds, lessThan(2000),
          reason: 'Fetching timetable API should respond within 2 seconds');
    });
  });
}
