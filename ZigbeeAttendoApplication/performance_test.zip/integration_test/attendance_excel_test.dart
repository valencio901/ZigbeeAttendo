import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() {
  const String apiUrl =
      'https://8892-2409-4042-6e98-bbe2-1915-272e-c03e-d5cc.ngrok-free.app/list_files.php';

  test('Stress test: API should handle multiple requests', () async {
    const int numberOfRequests = 50;
    List<Future<http.Response>> requests = [];

    for (int i = 0; i < numberOfRequests; i++) {
      requests.add(http.get(Uri.parse(apiUrl)));
    }

    final responses = await Future.wait(requests);

    for (var response in responses) {
      expect(response.statusCode, 200);
      expect(json.decode(response.body), isA<List>());
    }

    print(
        'Stress test passed: $numberOfRequests requests completed successfully.');
  });
}
