import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:http/http.dart' as http;
import 'package:mockito/mockito.dart';
import 'package:aats_app/teacher register page.dart';

// Mocking the HTTP client
class MockClient extends Mock implements http.Client {}

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group('TeacherRegisterPage Tests', () {
    // 📌 **UI Test: Page Rendering**
    testWidgets('TeacherRegisterPage UI elements should be rendered properly',
        (WidgetTester tester) async {
      await tester.pumpWidget(MaterialApp(home: TeacherRegisterPage()));

      // Verify presence of registration elements
      expect(find.text('Register'), findsOneWidget);
      expect(find.text('Name'), findsOneWidget);
      expect(find.text('Phone Number'), findsOneWidget);
      expect(find.text('Address'), findsOneWidget);
      expect(find.text('Password'), findsOneWidget);
      expect(find.byType(TextField),
          findsNWidgets(4)); // Name, Phone, Address, Password
      expect(find.byType(ElevatedButton), findsOneWidget);
    });

    // 📌 **Input Validation Test**
    testWidgets('Should show an error if fields are empty',
        (WidgetTester tester) async {
      await tester.pumpWidget(MaterialApp(home: TeacherRegisterPage()));

      // Tap register button without entering any data
      await tester.tap(find.byType(ElevatedButton));
      await tester.pump();

      // Verify error message appears
      expect(find.text("Please fill in all fields"), findsOneWidget);
    });

    // 📌 **API Test: Successful Registration**
    testWidgets('Successful registration should show success message',
        (WidgetTester tester) async {
      final client = MockClient();
      when(client.post(any, body: anyNamed('body')))
          .thenAnswer((_) async => http.Response(
                jsonEncode({
                  "status": "success",
                  "message": "Teacher registered successfully"
                }),
                200,
              ));

      await tester.pumpWidget(MaterialApp(home: TeacherRegisterPage()));

      // Enter valid details
      await tester.enterText(find.byType(TextField).at(0), "John Doe");
      await tester.enterText(find.byType(TextField).at(1), "9876543210");
      await tester.enterText(find.byType(TextField).at(2), "New York, USA");
      await tester.enterText(find.byType(TextField).at(3), "securepassword");

      // Tap register button
      await tester.tap(find.byType(ElevatedButton));
      await tester.pumpAndSettle();

      // Verify success message
      expect(find.text("Teacher registered successfully"), findsOneWidget);
    });

    // 📌 **API Test: Server Error**
    testWidgets('Server failure should show an error message',
        (WidgetTester tester) async {
      final client = MockClient();
      when(client.post(any, body: anyNamed('body'))).thenAnswer((_) async =>
          http.Response(
            jsonEncode({"status": "error", "message": "Registration failed"}),
            500,
          ));

      await tester.pumpWidget(MaterialApp(home: TeacherRegisterPage()));

      // Enter valid details
      await tester.enterText(find.byType(TextField).at(0), "John Doe");
      await tester.enterText(find.byType(TextField).at(1), "9876543210");
      await tester.enterText(find.byType(TextField).at(2), "New York, USA");
      await tester.enterText(find.byType(TextField).at(3), "securepassword");

      // Tap register button
      await tester.tap(find.byType(ElevatedButton));
      await tester.pumpAndSettle();

      // Verify error message
      expect(find.text("Registration failed"), findsOneWidget);
    });

    // 📌 **Performance Test: Registration Response Time**
    testWidgets('Registration API should respond within acceptable time',
        (WidgetTester tester) async {
      final stopwatch = Stopwatch()..start();

      final client = MockClient();
      when(client.post(any, body: anyNamed('body')))
          .thenAnswer((_) async => http.Response(
                jsonEncode({"status": "success"}),
                200,
              ));

      await tester.pumpWidget(MaterialApp(home: TeacherRegisterPage()));

      // Enter details
      await tester.enterText(find.byType(TextField).at(0), "John Doe");
      await tester.enterText(find.byType(TextField).at(1), "9876543210");
      await tester.enterText(find.byType(TextField).at(2), "New York, USA");
      await tester.enterText(find.byType(TextField).at(3), "securepassword");

      // Tap register button
      await tester.tap(find.byType(ElevatedButton));
      await tester.pumpAndSettle();

      stopwatch.stop();
      print('Registration response time: ${stopwatch.elapsedMilliseconds} ms');

      // Ensure API responds within 2 seconds
      expect(stopwatch.elapsedMilliseconds, lessThan(2000),
          reason: 'Registration API should respond within 2 seconds');
    });
  });
}
