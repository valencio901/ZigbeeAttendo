import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:your_app/TimeTableOf.dart'; // Update with the correct import
import 'package:your_app/TiimeTables.dart'; // Import where MyApp is defined

void main() {
  group('TimeTableOf Page Tests', () {
    testWidgets('Page loads successfully', (WidgetTester tester) async {
      final stopwatch = Stopwatch()..start();

      await tester.pumpWidget(MaterialApp(home: Timetableof()));
      await tester.pumpAndSettle();

      stopwatch.stop();
      print('TimeTableOf page loaded in ${stopwatch.elapsedMilliseconds} ms');

      expect(find.text('SELECT CLASS'), findsOneWidget);
      expect(stopwatch.elapsedMilliseconds, lessThan(700),
          reason: 'Page should load in under 700ms');
    });

    testWidgets('All class buttons are present', (WidgetTester tester) async {
      await tester.pumpWidget(MaterialApp(home: Timetableof()));

      final classes = [
        'FYBCA A',
        'FYBCA B',
        'SYBCA A',
        'SYBCA B',
        'TYBCA A',
        'TYBCA B',
        'FYBVOC A',
        'FYBVOC B',
        'SYBVOC A',
        'SYBVOC B',
        'TYBVOC A',
        'TYBVOC B'
      ];

      for (final className in classes) {
        expect(find.text(className), findsOneWidget);
      }
    });

    testWidgets('Button tap navigates to timetable page',
        (WidgetTester tester) async {
      await tester.pumpWidget(MaterialApp(
        home: Timetableof(),
        routes: {
          '/timetable': (context) => MyApp(className: 'Test Class'),
        },
      ));

      final button = find.text('FYBCA A');
      await tester.tap(button);
      await tester.pumpAndSettle();

      expect(find.byType(MyApp), findsOneWidget);
    });

    testWidgets('Stress test - Rapid button taps', (WidgetTester tester) async {
      await tester.pumpWidget(MaterialApp(home: Timetableof()));

      final button = find.text('FYBCA A');

      for (int i = 0; i < 10; i++) {
        await tester.tap(button);
        await tester.pumpAndSettle();
        await tester.pageBack();
        await tester.pumpAndSettle();
      }

      expect(find.text('SELECT CLASS'), findsOneWidget);
    });
  });
}
