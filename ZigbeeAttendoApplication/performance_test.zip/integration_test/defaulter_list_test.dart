import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:aats_app/main.dart'; // Replace with your actual main app file
import 'package:aats_app/DangerListPage.dart'; // Ensure correct import path

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group('DangerListPage Tests', () {
    // 📌 **Page Load Speed Test**
    testWidgets('DangerListPage should load within acceptable time',
        (WidgetTester tester) async {
      final stopwatch = Stopwatch()..start();

      // Start the app and navigate to DangerListPage
      await tester.pumpWidget(MaterialApp(
        home:
            DangerListPage(className: "FYBCA A"), // Adjust with any valid class
      ));
      await tester.pumpAndSettle(); // Wait until all animations finish

      stopwatch.stop();
      print('Page load time: ${stopwatch.elapsedMilliseconds} ms');

      // Ensure the page loads within 3 seconds
      expect(stopwatch.elapsedMilliseconds, lessThan(3000),
          reason: 'Page should load within 3 seconds');
    });

    // 📌 **UI Stress Test**
    testWidgets('Stress test: Rapid user interactions',
        (WidgetTester tester) async {
      await tester.pumpWidget(MaterialApp(
        home: DangerListPage(className: "FYBCA A"),
      ));
      await tester.pumpAndSettle();

      final Finder buttonFinder = find.byType(TextButton);
      final Finder scrollableList = find.byType(SingleChildScrollView);

      // Tap buttons rapidly multiple times
      for (int i = 0; i < 10; i++) {
        await tester.tap(buttonFinder.first);
        await tester.pumpAndSettle();
      }

      // Rapidly scroll list
      for (int i = 0; i < 5; i++) {
        await tester.fling(scrollableList, const Offset(0, -500), 1000);
        await tester.pumpAndSettle();
      }

      print("UI stress test passed: Handled rapid taps and scrolling.");
    });

    // 📌 **API Stress Test** (Mock API)
    test('API Stress Test: DangerListPage API should handle multiple requests',
        () async {
      const String apiUrl =
          'https://8892-2409-4042-6e98-bbe2-1915-272e-c03e-d5cc.ngrok-free.app/below_75.php?className=FYBCA A';

      const int requestCount = 50; // Number of requests to simulate
      List<Future<http.Response>> requests = [];

      // Fire multiple requests simultaneously
      for (int i = 0; i < requestCount; i++) {
        requests.add(http.get(Uri.parse(apiUrl)));
      }

      final responses = await Future.wait(requests);

      for (var response in responses) {
        expect(response.statusCode, 200, reason: 'API should return 200 OK');
        expect(json.decode(response.body), isA<List>(),
            reason: 'Response should be a valid JSON list');
      }

      print('Stress test passed: $requestCount requests handled successfully.');
    });

    // 📌 **Performance Test for Button Press**
    testWidgets('Button press should respond within acceptable time',
        (WidgetTester tester) async {
      final stopwatch = Stopwatch()..start();

      await tester.pumpWidget(MaterialApp(
        home: DangerListPage(className: "FYBCA A"),
      ));
      await tester.pumpAndSettle();

      // Find a button and simulate a press
      final Finder button = find.text('FYBCA A'); // Adjust for any section
      await tester.tap(button);
      await tester.pumpAndSettle();

      stopwatch.stop();
      print('Button press time: ${stopwatch.elapsedMilliseconds} ms');

      // Ensure that the button press completes in less than 500 milliseconds
      expect(stopwatch.elapsedMilliseconds, lessThan(500),
          reason: 'Button press should be quick');
    });

    // 📌 **Memory Stress Test**
    testWidgets('Stress test: Handling large number of data rows',
        (WidgetTester tester) async {
      await tester.pumpWidget(MaterialApp(
        home: DangerListPage(className: "FYBCA A"),
      ));
      await tester.pumpAndSettle();

      // Simulate a large number of rows (100 rows for testing)
      List<Map<String, dynamic>> fakeData = List.generate(
          100,
          (index) => {
                'rollno': 'S$index',
                'subject': 'Math',
                'total_lectures': 50,
                'attended_lectures': 40,
                'attendance_percentage': 75.0,
              });

      // Manually set the danger list data to simulate the API response
      await tester.pumpWidget(MaterialApp(
        home: DangerListPage(className: "FYBCA A"),
      ));
      await tester.pumpAndSettle();

      // Ensure that at least one entry exists in the list
      expect(find.text('S99'), findsOneWidget,
          reason: "Data row 'S99' should be present.");

      // Check that the number of rows is correct (100)
      for (var data in fakeData) {
        expect(find.text(data['rollno']), findsOneWidget,
            reason: "Roll No '${data['rollno']}' should be rendered.");
      }

      print("Memory stress test passed: Handled a large number of rows.");
    });
  });
}
