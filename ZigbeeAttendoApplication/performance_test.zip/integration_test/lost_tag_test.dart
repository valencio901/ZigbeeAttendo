import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:mockito/mockito.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:aats_app/Lost Tag.dart';
// Mocking the HTTP client
class MockClient extends Mock implements http.Client {}

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group('LostTagPage Tests', () {
    // 📌 **Page Load Speed Test**
    testWidgets('LostTagPage should load within acceptable time',
        (WidgetTester tester) async {
      final stopwatch = Stopwatch()..start();

      await tester.pumpWidget(MaterialApp(
        home: LostTagPage(),
      ));
      await tester.pumpAndSettle(); // Wait until all animations finish

      stopwatch.stop();
      print('Page load time: ${stopwatch.elapsedMilliseconds} ms');

      // Ensure the page loads within 3 seconds
      expect(stopwatch.elapsedMilliseconds, lessThan(3000),
          reason: 'Page should load within 3 seconds');
    });

    // 📌 **UI Stress Test**
    testWidgets('Stress test: Form filling and button click',
        (WidgetTester tester) async {
      await tester.pumpWidget(MaterialApp(
        home: LostTagPage(),
      ));
      await tester.pumpAndSettle();

      // Enter data into the text fields
      await tester.enterText(find.byType(TextField).at(0), '1234'); // Roll No
      await tester.enterText(find.byType(TextField).at(1), 'FYBCA A'); // Class
      await tester.enterText(
          find.byType(TextField).at(2), 'Room 101'); // Classroom
      await tester.enterText(
          find.byType(TextField).at(3), 'Lost my ID tag'); // Report

      // Tap on the submit button
      await tester.tap(find.text('Report to Office'));
      await tester.pumpAndSettle();

      // Verify that the success dialog appears
      expect(find.text('Reported to the office'), findsOneWidget);

      print("UI stress test passed: Handled form filling and submission.");
    });

    // 📌 **API Test (Mocking HTTP Request)**
    test('Test API submission and response handling', () async {
      final client = MockClient();
      when(client.post(any, body: anyNamed('body')))
          .thenAnswer((_) async => http.Response('{"status": "success"}', 200));

      const String url =
          'https://8892-2409-4042-6e98-bbe2-1915-272e-c03e-d5cc.ngrok-free.app/insert_report.php';

      final response = await client.post(Uri.parse(url), body: {
        'rollno': '1234',
        'class': 'FYBCA A',
        'classroom': 'Room 101',
        'report': 'Lost my ID tag',
      });

      expect(response.statusCode, 200);
      expect(json.decode(response.body)['status'], 'success');

      print("API test passed: Successfully mocked API response.");
    });

    // 📌 **Performance Test: Form submission time**
    testWidgets('Form submission should respond within acceptable time',
        (WidgetTester tester) async {
      final stopwatch = Stopwatch()..start();

      await tester.pumpWidget(MaterialApp(
        home: LostTagPage(),
      ));
      await tester.pumpAndSettle();

      // Enter data into the text fields
      await tester.enterText(find.byType(TextField).at(0), '1234'); // Roll No
      await tester.enterText(find.byType(TextField).at(1), 'FYBCA A'); // Class
      await tester.enterText(
          find.byType(TextField).at(2), 'Room 101'); // Classroom
      await tester.enterText(
          find.byType(TextField).at(3), 'Lost my ID tag'); // Report

      // Tap on the submit button
      await tester.tap(find.text('Report to Office'));
      await tester.pumpAndSettle();

      stopwatch.stop();
      print('Form submission time: ${stopwatch.elapsedMilliseconds} ms');

      // Ensure that the form submission completes in less than 2 seconds
      expect(stopwatch.elapsedMilliseconds, lessThan(2000),
          reason: 'Form submission should be quick');
    });

    // 📌 **Error Handling Test**
    testWidgets('Test error handling for API failure',
        (WidgetTester tester) async {
      final client = MockClient();
      when(client.post(any, body: anyNamed('body')))
          .thenAnswer((_) async => http.Response('{"status": "error"}', 400));

      const String url =
          'https://8892-2409-4042-6e98-bbe2-1915-272e-c03e-d5cc.ngrok-free.app/insert_report.php';

      final response = await client.post(Uri.parse(url), body: {
        'rollno': '1234',
        'class': 'FYBCA A',
        'classroom': 'Room 101',
        'report': 'Lost my ID tag',
      });

      // Simulating error response handling in your UI (showing a message to the user)
      expect(response.statusCode, 400);
      expect(json.decode(response.body)['status'], 'error');

      print("Error handling test passed: Handled API failure.");
    });
  });
}
