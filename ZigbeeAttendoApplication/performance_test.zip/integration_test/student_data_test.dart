import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:http/http.dart' as http;
import 'package:mockito/mockito.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:aats_app/student data.dart';

// Mocking the HTTP client
class MockClient extends Mock implements http.Client {}

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group('StudentDataPage Tests', () {
    // 📌 **Page Load Speed Test**
    testWidgets('StudentDataPage should load within acceptable time',
        (WidgetTester tester) async {
      final stopwatch = Stopwatch()..start();

      await tester.pumpWidget(MaterialApp(
        home: StudentDataPage(
          rollno: '1234',
          classs: 'FYBCA A',
        ),
      ));
      await tester.pumpAndSettle(); // Wait until all animations finish

      stopwatch.stop();
      print('Page load time: ${stopwatch.elapsedMilliseconds} ms');

      // Ensure the page loads within 3 seconds
      expect(stopwatch.elapsedMilliseconds, lessThan(3000),
          reason: 'Page should load within 3 seconds');
    });

    // 📌 **UI Stress Test: Data Fetching and Rendering Pie Chart**
    testWidgets('Stress test: Fetch data and render Pie Chart',
        (WidgetTester tester) async {
      final client = MockClient();
      when(client.get(any)).thenAnswer((_) async => http.Response(
            '{"attendance": [{"date": "2022-12-01", "attendance": "Present"}, {"date": "2022-12-02", "attendance": "Absent"}], "numLectures": 2}',
            200,
          ));
      when(client.post(any,
              headers: anyNamed('headers'), body: anyNamed('body')))
          .thenAnswer((_) async => http.Response(
                '{"status": "success", "student": {"name": "John Doe", "classroom": "Room 101", "college": "XYZ College"}}',
                200,
              ));
      when(client.get(any)).thenAnswer((_) async => http.Response(
            '{"status": "success", "subjects": ["Math", "Science"]}',
            200,
          ));

      await tester.pumpWidget(MaterialApp(
        home: StudentDataPage(
          rollno: '1234',
          classs: 'FYBCA A',
        ),
      ));

      // Wait for data fetching to finish
      await tester.pumpAndSettle();

      // Verify that the name and class details are rendered
      expect(find.text('John Doe'), findsOneWidget);
      expect(find.text('Class: FYBCA A'), findsOneWidget);
      expect(find.text('Classroom: Room 101'), findsOneWidget);
      expect(find.text('College: XYZ College'), findsOneWidget);

      // Verify the pie chart and timetable are rendered
      expect(find.byType(PieChart), findsOneWidget);
      expect(find.text('Lectures Attended: 1'), findsOneWidget);
      expect(find.text('Total Lectures: 2'), findsOneWidget);
      expect(find.text('Math'), findsOneWidget);
      expect(find.text('Science'), findsOneWidget);

      print("UI stress test passed: Data successfully fetched and rendered.");
    });

    // 📌 **API Test (Mocking HTTP Request for Student Data)**
    test('Test API submission and response handling (mocked)', () async {
      final client = MockClient();
      when(client.post(any,
              headers: anyNamed('headers'), body: anyNamed('body')))
          .thenAnswer((_) async => http.Response(
                '{"status": "success", "student": {"name": "John Doe", "classroom": "Room 101", "college": "XYZ College"}}',
                200,
              ));

      final url = Uri.parse(
          'https://8bc4-2409-4042-6ec9-1f2b-91fb-986-2aae-1a64.ngrok-free.app/get_student_data.php');
      final response = await client.post(url,
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({'rollno': '1234', 'class': 'FYBCA A'}));

      expect(response.statusCode, 200);
      final data = json.decode(response.body);
      expect(data['status'], 'success');
      expect(data['student']['name'], 'John Doe');
      expect(data['student']['classroom'], 'Room 101');
      expect(data['student']['college'], 'XYZ College');

      print("API test passed: Successfully mocked API response.");
    });

    // 📌 **Performance Test: Data Fetching Speed**
    testWidgets('Data fetching should respond within acceptable time',
        (WidgetTester tester) async {
      final stopwatch = Stopwatch()..start();

      final client = MockClient();
      when(client.get(any)).thenAnswer((_) async => http.Response(
            '{"attendance": [{"date": "2022-12-01", "attendance": "Present"}], "numLectures": 1}',
            200,
          ));
      when(client.post(any,
              headers: anyNamed('headers'), body: anyNamed('body')))
          .thenAnswer((_) async => http.Response(
                '{"status": "success", "student": {"name": "John Doe", "classroom": "Room 101", "college": "XYZ College"}}',
                200,
              ));
      when(client.get(any)).thenAnswer((_) async => http.Response(
            '{"status": "success", "subjects": ["Math", "Science"]}',
            200,
          ));

      await tester.pumpWidget(MaterialApp(
        home: StudentDataPage(
          rollno: '1234',
          classs: 'FYBCA A',
        ),
      ));

      // Wait for data fetching to finish
      await tester.pumpAndSettle();

      stopwatch.stop();
      print('Data fetching time: ${stopwatch.elapsedMilliseconds} ms');

      // Ensure that the data fetching time is less than 2000ms
      expect(stopwatch.elapsedMilliseconds, lessThan(2000),
          reason: 'Data fetching should be quick');
    });

    // 📌 **Error Handling Test: API Failure Simulation**
    testWidgets('Error handling: Show error message on API failure',
        (WidgetTester tester) async {
      final client = MockClient();
      when(client.get(any)).thenAnswer(
          (_) async => http.Response('Failed to load student data', 500));

      await tester.pumpWidget(MaterialApp(
        home: StudentDataPage(
          rollno: '1234',
          classs: 'FYBCA A',
        ),
      ));

      // Wait for the FutureBuilder to finish loading
      await tester.pumpAndSettle();

      // Verify that the error message is shown
      expect(find.text('Failed to load student data'), findsOneWidget);

      print("Error handling test passed: Error message displayed.");
    });
  });
}
