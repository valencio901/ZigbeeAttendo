import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:mqtt_client/mqtt_server_client.dart'; // MQTT Client
import 'dart:async';
import 'package:aats_app/main.dart'; // Replace with your actual main app file
import 'package:mockito/mockito.dart'; // For mocking dependencies
import 'package:aats_app/live.dart';

// Mock MqttClient
class MockMqttServerClient extends Mock implements MqttServerClient {}

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group('SerialDataScreen Tests', () {
    // 📌 **UI Stress Test**
    testWidgets('Stress test: Rapid UI updates with MQTT messages',
        (WidgetTester tester) async {
      final client = MockMqttServerClient();
      when(client.connect())
          .thenAnswer((_) async => MqttConnectionStatus.connected);
      when(client.subscribe(any, any)).thenAnswer((_) => Future.value());
      when(client.updates).thenReturn(Stream.value([
        MqttReceivedMessage(MqttPublishMessage(), MqttTopic('esp32/serial'), 0)
      ]));

      // Start the app and pass the mock client
      await tester.pumpWidget(MaterialApp(
        home: SerialDataScreen(),
      ));

      // Simulate the connection to the MQTT broker
      await tester.pumpAndSettle();

      // Simulate receiving messages
      await tester.pump(const Duration(seconds: 1));

      // Verify that the serial output is updated
      expect(find.text('Serial Output: '), findsOneWidget);

      print("UI stress test passed: Handled rapid UI updates from MQTT.");
    });

    // 📌 **Performance Test: Connection and Message Handling**
    testWidgets('MQTT connection should respond within acceptable time',
        (WidgetTester tester) async {
      final client = MockMqttServerClient();
      when(client.connect())
          .thenAnswer((_) async => MqttConnectionStatus.connected);
      when(client.subscribe(any, any)).thenAnswer((_) => Future.value());
      when(client.updates).thenReturn(Stream.value([
        MqttReceivedMessage(MqttPublishMessage(), MqttTopic('esp32/serial'), 0)
      ]));

      final stopwatch = Stopwatch()..start();

      // Start the app and pass the mock client
      await tester.pumpWidget(MaterialApp(
        home: SerialDataScreen(),
      ));

      // Simulate the connection and message handling
      await tester.pumpAndSettle();

      stopwatch.stop();
      print(
          'MQTT connection and message handling time: ${stopwatch.elapsedMilliseconds} ms');

      // Ensure the connection and message processing completes within 2 seconds
      expect(stopwatch.elapsedMilliseconds, lessThan(2000),
          reason: 'MQTT connection should complete quickly');
    });

    // 📌 **Connection Error Handling Test**
    testWidgets('Test MQTT connection failure and handle errors gracefully',
        (WidgetTester tester) async {
      final client = MockMqttServerClient();
      when(client.connect())
          .thenAnswer((_) async => MqttConnectionStatus.error);
      when(client.subscribe(any, any)).thenAnswer((_) => Future.value());
      when(client.updates).thenReturn(Stream.empty());

      await tester.pumpWidget(MaterialApp(
        home: SerialDataScreen(),
      ));

      // Simulate the connection failure
      await tester.pumpAndSettle();

      // Verify that the UI is handling the error (you may want to add an error message in your actual implementation)
      expect(find.text('Failed to connect to MQTT broker'), findsOneWidget);

      print("Connection error handling test passed.");
    });

    // 📌 **Memory Stress Test: Handling large number of messages**
    testWidgets('Stress test: Handling large number of MQTT messages',
        (WidgetTester tester) async {
      final client = MockMqttServerClient();
      when(client.connect())
          .thenAnswer((_) async => MqttConnectionStatus.connected);
      when(client.subscribe(any, any)).thenAnswer((_) => Future.value());
      when(client.updates)
          .thenReturn(Stream.fromIterable(List.generate(1000, (_) {
        return MqttReceivedMessage(
            MqttPublishMessage(), MqttTopic('esp32/serial'), 0);
      })));

      await tester.pumpWidget(MaterialApp(
        home: SerialDataScreen(),
      ));

      // Simulate the large number of messages being received
      await tester.pumpAndSettle();

      // Verify that the app can handle the display of large numbers of messages
      expect(find.text('Serial Output: '), findsOneWidget);

      print(
          "Memory stress test passed: Handled large number of MQTT messages.");
    });
  });
}
