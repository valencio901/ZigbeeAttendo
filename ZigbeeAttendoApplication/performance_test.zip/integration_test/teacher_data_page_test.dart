import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:aats_app/teachers data.dart';
import 'package:aats_app/teachers attendence.dart';
import 'package:aats_app/teacher view student attendence.dart';

class MockHttpClient extends Mock implements http.Client {}

void main() {
  group('TeacherDataPage Tests', () {
    late MockHttpClient mockHttpClient;

    setUp(() {
      mockHttpClient = MockHttpClient();
    });

    testWidgets('Page loads successfully', (WidgetTester tester) async {
      final stopwatch = Stopwatch()..start();

      await tester.pumpWidget(
          MaterialApp(home: TeacherDataPage(teacherName: 'Mr. Smith')));
      await tester.pumpAndSettle();

      stopwatch.stop();
      print('TeacherDataPage loaded in ${stopwatch.elapsedMilliseconds} ms');

      expect(find.text('Teachers Dashboard'), findsOneWidget);
      expect(stopwatch.elapsedMilliseconds, lessThan(1000),
          reason: 'Page should load in under 1000ms');
    });

    testWidgets('Teacher details fetches correctly',
        (WidgetTester tester) async {
      final mockResponse = {
        'teacher_name': 'Mr. Smith',
        'phone_number': '1234567890',
        'address': '123 Main St'
      };

      when(mockHttpClient.get(any)).thenAnswer(
          (_) async => http.Response(json.encode(mockResponse), 200));

      await tester.pumpWidget(
          MaterialApp(home: TeacherDataPage(teacherName: 'Mr. Smith')));
      await tester.pumpAndSettle();

      expect(find.text('Mr. Smith'), findsOneWidget);
      expect(find.text('Phone No: 1234567890'), findsOneWidget);
      expect(find.text('Address: 123 Main St'), findsOneWidget);
    });

    testWidgets('Class schedule fetches correctly',
        (WidgetTester tester) async {
      final mockResponse = {
        'success': true,
        'data': [
          {'classroom': 'A1', 'subject': 'Math', 'time': '10:00 AM'}
        ]
      };

      when(mockHttpClient.get(any)).thenAnswer(
          (_) async => http.Response(json.encode(mockResponse), 200));

      await tester.pumpWidget(
          MaterialApp(home: TeacherDataPage(teacherName: 'Mr. Smith')));
      await tester.pumpAndSettle();

      expect(find.text('A1'), findsOneWidget);
      expect(find.text('Math'), findsOneWidget);
      expect(find.text('10:00 AM'), findsOneWidget);
    });

    testWidgets('Navigation: View Your Attendance',
        (WidgetTester tester) async {
      await tester.pumpWidget(MaterialApp(
        home: TeacherDataPage(teacherName: 'Mr. Smith'),
        routes: {
          '/teacherAttendance': (context) =>
              TeacherAttendance(teacherName: 'Mr. Smith'),
        },
      ));

      await tester.tap(find.text('View Your Attendance'));
      await tester.pumpAndSettle();

      expect(find.byType(TeacherAttendance), findsOneWidget);
    });

    testWidgets('Navigation: View Students Attendance',
        (WidgetTester tester) async {
      await tester.pumpWidget(MaterialApp(
        home: TeacherDataPage(teacherName: 'Mr. Smith'),
        routes: {
          '/teacherViewStudentAttendance': (context) =>
              TeacherViewAttendancePage(teacherName: 'Mr. Smith'),
        },
      ));

      await tester.tap(find.text('View Students Attendance'));
      await tester.pumpAndSettle();

      expect(find.byType(TeacherViewAttendancePage), findsOneWidget);
    });

    testWidgets('Edit button opens dialog and saves changes',
        (WidgetTester tester) async {
      await tester.pumpWidget(
          MaterialApp(home: TeacherDataPage(teacherName: 'Mr. Smith')));

      await tester.pumpAndSettle();

      final editButton = find.byIcon(Icons.edit);
      expect(editButton, findsOneWidget);

      await tester.tap(editButton);
      await tester.pumpAndSettle();

      expect(find.text('Edit Class'), findsOneWidget);

      await tester.enterText(find.byType(TextField).at(0), 'A2');
      await tester.enterText(find.byType(TextField).at(1), 'Science');
      await tester.enterText(find.byType(TextField).at(2), '11:00 AM');

      await tester.tap(find.text('Save'));
      await tester.pumpAndSettle();

      expect(find.text('A2'), findsOneWidget);
      expect(find.text('Science'), findsOneWidget);
      expect(find.text('11:00 AM'), findsOneWidget);
    });

    testWidgets('Stress test - Rapid button taps', (WidgetTester tester) async {
      await tester.pumpWidget(
          MaterialApp(home: TeacherDataPage(teacherName: 'Mr. Smith')));

      final editButton = find.byIcon(Icons.edit);

      for (int i = 0; i < 5; i++) {
        await tester.tap(editButton);
        await tester.pumpAndSettle();
        await tester.tap(find.text('Cancel'));
        await tester.pumpAndSettle();
      }

      expect(find.text('Teachers Dashboard'), findsOneWidget);
    });
  });
}
