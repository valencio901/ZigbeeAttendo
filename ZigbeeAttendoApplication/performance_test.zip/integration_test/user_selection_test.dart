import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:aats_app/user selection.dart';

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group('WhoAreYouPage Performance Test', () {
    testWidgets('Page Load Speed Test', (WidgetTester tester) async {
      final stopwatch = Stopwatch()..start();

      await tester.pumpWidget(const MaterialApp(home: WhoAreYouPage()));
      await tester.pumpAndSettle(); // Wait until animations finish

      stopwatch.stop();
      print('WhoAreYouPage loaded in ${stopwatch.elapsedMilliseconds} ms');

      expect(stopwatch.elapsedMilliseconds, lessThan(500),
          reason: 'Page should load in under 500ms');
    });

    testWidgets('Stress Test - Rapid Button Press',
        (WidgetTester tester) async {
      await tester.pumpWidget(const MaterialApp(home: WhoAreYouPage()));
      await tester.pumpAndSettle();

      final teacherButton = find.text('Teacher');
      final studentButton = find.text('Student');
      final principalButton = find.text('Principal');

      for (int i = 0; i < 10; i++) {
        await tester.tap(teacherButton);
        await tester.pumpAndSettle();
        await tester.pageBack(); // Navigate back

        await tester.tap(studentButton);
        await tester.pumpAndSettle();
        await tester.pageBack();

        await tester.tap(principalButton);
        await tester.pumpAndSettle();
        await tester.pageBack();
      }

      expect(teacherButton, findsOneWidget);
      expect(studentButton, findsOneWidget);
      expect(principalButton, findsOneWidget);
    });
  });
}
