import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:mockito/mockito.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:aats_app/teacher view student attendence.dart';
import 'package:mockito/annotations.dart';

@GenerateMocks([http.Client]) // This tells Mockito to generate a mock client
void main() {
  late MockClient mockHttpClient; // Use generated mock class

  setUp(() {
    mockHttpClient = MockClient(); // Instantiate the generated mock
  });

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group('TeacherViewAttendancePage Performance Test', () {
    late MockHttpClient mockHttpClient;

    setUp(() {
      mockHttpClient = MockHttpClient();
    });

    testWidgets('Page Load Speed Test', (WidgetTester tester) async {
      final stopwatch = Stopwatch()..start();

      await tester.pumpWidget(const MaterialApp(
          home: TeacherViewAttendancePage(teacherName: 'Mr. Smith')));
      await tester.pumpAndSettle();

      stopwatch.stop();
      print(
          'TeacherViewAttendancePage loaded in ${stopwatch.elapsedMilliseconds} ms');

      expect(stopwatch.elapsedMilliseconds, lessThan(700),
          reason: 'Page should load in under 700ms');
    });

    testWidgets('API Response Time Test', (WidgetTester tester) async {
      final mockResponse = {
        'attendanceRecords': [
          {
            'rollno': '101',
            'date': '2025-02-10',
            'subject': 'Math',
            'time': '10:00 AM',
            'classroom': 'A1',
            'attendance': 'Present',
            'database': 'Class 10A'
          }
        ]
      };

      when(mockHttpClient.get(any)).thenAnswer(
          (_) async => http.Response(json.encode(mockResponse), 200));

      final stopwatch = Stopwatch()..start();

      await tester.pumpWidget(const MaterialApp(
          home: TeacherViewAttendancePage(teacherName: 'Mr. Smith')));
      await tester.pumpAndSettle();

      stopwatch.stop();
      print('API Response Time: ${stopwatch.elapsedMilliseconds} ms');

      expect(stopwatch.elapsedMilliseconds, lessThan(1000),
          reason: 'API should respond in under 1000ms');
    });

    testWidgets('Stress Test - Multiple API Calls',
        (WidgetTester tester) async {
      await tester.pumpWidget(const MaterialApp(
          home: TeacherViewAttendancePage(teacherName: 'Mr. Smith')));
      await tester.pumpAndSettle();

      for (int i = 0; i < 10; i++) {
        await tester.tap(find.byType(Scaffold));
        await tester.pumpAndSettle();
      }

      expect(find.text('Attendance Records'), findsOneWidget);
    });
  });
}
