import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:flutter/material.dart';
import 'package:aats_app/ComputerScienceDepartmentPage.dart';

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group('ComputerScienceDepartmentPage Stress Tests', () {
    // 📌 **Page Load Speed Test**
    testWidgets('Page should load within acceptable time',
        (WidgetTester tester) async {
      final stopwatch = Stopwatch()..start();

      // Start the app and navigate to ComputerScienceDepartmentPage
      await tester.pumpWidget(MaterialApp(
        home: ComputerScienceDepartmentPage(),
      ));
      await tester.pumpAndSettle(); // Wait until all animations finish

      stopwatch.stop();
      print('Page load time: ${stopwatch.elapsedMilliseconds} ms');

      // Ensure the page loads within 3 seconds
      expect(stopwatch.elapsedMilliseconds, lessThan(3000),
          reason: 'Page should load within 3 seconds');
    });

    // 📌 **UI Stress Test**
    testWidgets('Stress test: Rapid user interactions',
        (WidgetTester tester) async {
      await tester.pumpWidget(MaterialApp(
        home: ComputerScienceDepartmentPage(),
      ));
      await tester.pumpAndSettle();

      final Finder buttonFinder = find.byType(TextButton);
      final Finder scrollableList = find.byType(SingleChildScrollView);

      // Tap buttons rapidly multiple times
      for (int i = 0; i < 10; i++) {
        await tester.tap(buttonFinder.first);
        await tester.pumpAndSettle();
      }

      // Rapidly scroll list
      for (int i = 0; i < 5; i++) {
        await tester.fling(scrollableList, const Offset(0, -500), 1000);
        await tester.pumpAndSettle();
      }

      print("UI stress test passed: Handled rapid taps and scrolling.");
    });

    // 📌 **Memory Stress Test**
    testWidgets('Stress test: Handling large number of buttons',
        (WidgetTester tester) async {
      await tester.pumpWidget(MaterialApp(
        home: ComputerScienceDepartmentPage(),
      ));
      await tester.pumpAndSettle();

      // Simulate adding a large number of buttons (like in a class with many sections)
      final largeNumberOfButtons =
          List.generate(100, (index) => 'Section $index');

      // Test that the page handles the creation of a large number of buttons
      for (var label in largeNumberOfButtons) {
        expect(find.text(label), findsOneWidget,
            reason: "Button with label '$label' should be present.");
      }

      print("Memory stress test passed: Handled a large number of buttons.");
    });

    // 📌 **Dropdown Functionality Test**
    testWidgets('Button navigation should work correctly',
        (WidgetTester tester) async {
      await tester.pumpWidget(MaterialApp(
        home: ComputerScienceDepartmentPage(),
      ));
      await tester.pumpAndSettle();

      // Tap on one of the buttons
      await tester.tap(find.text('FYBCA A')); // Adjust based on button label
      await tester.pumpAndSettle();

      // Verify that the AttendancePage is displayed with the correct class name
      expect(find.text('Class FYBCA A'), findsOneWidget);

      print("Button navigation test passed.");
    });
  });
}
