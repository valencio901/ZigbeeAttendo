import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:http/http.dart' as http;
import 'package:mockito/mockito.dart';
import 'package:aats_app/main.dart'; // Adjust import path as needed
import 'package:aats_app/teacher login.dart';
import 'package:aats_app/teachers data.dart';

// Mock HTTP Client
class MockClient extends Mock implements http.Client {}

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group('TeacherLoginPage Tests', () {
    // 📌 **UI Test: Page Rendering**
    testWidgets('TeacherLoginPage UI elements should be rendered properly',
        (WidgetTester tester) async {
      await tester.pumpWidget(MaterialApp(home: TeacherLoginPage()));

      // Verify presence of login-related elements
      expect(find.text('Login'), findsOneWidget);
      expect(find.text('Teacher Name'), findsOneWidget);
      expect(find.text('Password'), findsOneWidget);
      expect(find.byType(TextField), findsNWidgets(2));
      expect(find.byType(ElevatedButton), findsOneWidget);
      expect(find.text('Register'), findsOneWidget);
    });

    // 📌 **Input Validation Test**
    testWidgets('Should show an error message if fields are empty',
        (WidgetTester tester) async {
      await tester.pumpWidget(MaterialApp(home: TeacherLoginPage()));

      // Tap login button without entering credentials
      await tester.tap(find.byType(ElevatedButton));
      await tester.pump();

      // Verify error message appears
      expect(find.text("Please enter both Teacher ID and Password."),
          findsOneWidget);
    });

    // 📌 **API Test: Successful Login**
    testWidgets('Successful login should navigate to TeacherDataPage',
        (WidgetTester tester) async {
      final client = MockClient();
      when(client.post(any, body: anyNamed('body')))
          .thenAnswer((_) async => http.Response(
                jsonEncode({"success": true}),
                200,
              ));

      await tester.pumpWidget(MaterialApp(home: TeacherLoginPage()));

      // Enter valid credentials
      await tester.enterText(find.byType(TextField).at(0), "JohnDoe");
      await tester.enterText(find.byType(TextField).at(1), "password123");

      // Tap login button
      await tester.tap(find.byType(ElevatedButton));
      await tester.pumpAndSettle();

      // Verify navigation to TeacherDataPage
      expect(find.byType(TeacherDataPage), findsOneWidget);
    });

    // 📌 **API Test: Incorrect Credentials**
    testWidgets('Incorrect login should display error message',
        (WidgetTester tester) async {
      final client = MockClient();
      when(client.post(any, body: anyNamed('body'))).thenAnswer((_) async =>
          http.Response(
            jsonEncode({"success": false, "message": "Invalid credentials"}),
            200,
          ));

      await tester.pumpWidget(MaterialApp(home: TeacherLoginPage()));

      // Enter incorrect credentials
      await tester.enterText(find.byType(TextField).at(0), "JohnDoe");
      await tester.enterText(find.byType(TextField).at(1), "wrongpassword");

      // Tap login button
      await tester.tap(find.byType(ElevatedButton));
      await tester.pumpAndSettle();

      // Verify error message
      expect(find.text("Invalid credentials"), findsOneWidget);
    });

    // 📌 **API Test: Server Failure**
    testWidgets('Server failure should display an error message',
        (WidgetTester tester) async {
      final client = MockClient();
      when(client.post(any, body: anyNamed('body')))
          .thenAnswer((_) async => http.Response('Internal Server Error', 500));

      await tester.pumpWidget(MaterialApp(home: TeacherLoginPage()));

      // Enter credentials
      await tester.enterText(find.byType(TextField).at(0), "JohnDoe");
      await tester.enterText(find.byType(TextField).at(1), "password123");

      // Tap login button
      await tester.tap(find.byType(ElevatedButton));
      await tester.pumpAndSettle();

      // Verify error message
      expect(find.text("An error occurred. Please try again later."),
          findsOneWidget);
    });

    // 📌 **Performance Test: Login Response Time**
    testWidgets('Login API should respond within acceptable time',
        (WidgetTester tester) async {
      final stopwatch = Stopwatch()..start();

      final client = MockClient();
      when(client.post(any, body: anyNamed('body')))
          .thenAnswer((_) async => http.Response(
                jsonEncode({"success": true}),
                200,
              ));

      await tester.pumpWidget(MaterialApp(home: TeacherLoginPage()));

      // Enter credentials
      await tester.enterText(find.byType(TextField).at(0), "JohnDoe");
      await tester.enterText(find.byType(TextField).at(1), "password123");

      // Tap login button
      await tester.tap(find.byType(ElevatedButton));
      await tester.pumpAndSettle();

      stopwatch.stop();
      print('Login response time: ${stopwatch.elapsedMilliseconds} ms');

      // Ensure API responds within 2 seconds
      expect(stopwatch.elapsedMilliseconds, lessThan(2000),
          reason: 'Login API should respond within 2 seconds');
    });

    // 📌 **Navigation Test: Register Page**
    testWidgets('Clicking Register should navigate to TeacherRegisterPage',
        (WidgetTester tester) async {
      await tester.pumpWidget(MaterialApp(home: TeacherLoginPage()));

      // Tap register button
      await tester.tap(find.text('Register'));
      await tester.pumpAndSettle();

      // Verify navigation to TeacherRegisterPage
      expect(find.byType(TeacherRegisterPage), findsOneWidget);
    });
  });
}
