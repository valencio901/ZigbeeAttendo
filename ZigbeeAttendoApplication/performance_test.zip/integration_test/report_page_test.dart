import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:http/http.dart' as http;
import 'package:mockito/mockito.dart';
import 'package:aats_app/reports.dart';

// Mock HTTP client
class MockClient extends Mock implements http.Client {}

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group('ReportPage Tests', () {
    // 📌 **Page Load Speed Test**
    testWidgets('ReportPage should load within acceptable time',
        (WidgetTester tester) async {
      final stopwatch = Stopwatch()..start();

      await tester.pumpWidget(MaterialApp(
        home: ReportPage(),
      ));
      await tester.pumpAndSettle(); // Wait until all animations finish

      stopwatch.stop();
      print('Page load time: ${stopwatch.elapsedMilliseconds} ms');

      // Ensure the page loads within 3 seconds
      expect(stopwatch.elapsedMilliseconds, lessThan(3000),
          reason: 'Page should load within 3 seconds');
    });

    // 📌 **UI Stress Test: API Success Simulation**
    testWidgets('Stress test: UI rendering and data fetching success',
        (WidgetTester tester) async {
      final client = MockClient();
      when(client.get(any)).thenAnswer((_) async => http.Response(
            '[{"rollno": "1234", "class": "FYBCA A", "classroom": "Room 101", "report": "Report details"}]',
            200,
          ));

      await tester.pumpWidget(MaterialApp(
        home: ReportPage(),
      ));

      // Wait for the FutureBuilder to finish loading the reports
      await tester.pumpAndSettle();

      // Verify that the report data is rendered on screen
      expect(find.text('Roll No: 1234'), findsOneWidget);
      expect(find.text('Class: FYBCA A'), findsOneWidget);
      expect(find.text('Classroom: Room 101'), findsOneWidget);
      expect(find.text('Report: Report details'), findsOneWidget);

      print("UI stress test passed: Data successfully fetched and displayed.");
    });

    // 📌 **Error Handling Test: API Failure Simulation**
    testWidgets('Error handling: Show error message on API failure',
        (WidgetTester tester) async {
      final client = MockClient();
      when(client.get(any)).thenAnswer(
          (_) async => http.Response('Failed to load reports', 500));

      await tester.pumpWidget(MaterialApp(
        home: ReportPage(),
      ));

      // Wait for the FutureBuilder to finish loading the reports
      await tester.pumpAndSettle();

      // Verify that error message is shown
      expect(find.text('Failed to load reports. Please try again later.'),
          findsOneWidget);

      print("Error handling test passed: Error message displayed.");
    });

    // 📌 **Performance Test: Data Fetching Speed**
    testWidgets('Data fetching should respond within acceptable time',
        (WidgetTester tester) async {
      final stopwatch = Stopwatch()..start();

      final client = MockClient();
      when(client.get(any)).thenAnswer((_) async => http.Response(
            '[{"rollno": "1234", "class": "FYBCA A", "classroom": "Room 101", "report": "Report details"}]',
            200,
          ));

      await tester.pumpWidget(MaterialApp(
        home: ReportPage(),
      ));

      // Wait for the FutureBuilder to finish loading the reports
      await tester.pumpAndSettle();

      stopwatch.stop();
      print('Data fetching time: ${stopwatch.elapsedMilliseconds} ms');

      // Ensure that the data fetching time is less than 2000ms
      expect(stopwatch.elapsedMilliseconds, lessThan(2000),
          reason: 'Data fetching should be fast');
    });

    // 📌 **UI Test: No Data Available**
    testWidgets('Display No Reports message if no data is available',
        (WidgetTester tester) async {
      final client = MockClient();
      when(client.get(any)).thenAnswer((_) async => http.Response('[]', 200));

      await tester.pumpWidget(MaterialApp(
        home: ReportPage(),
      ));

      // Wait for the FutureBuilder to finish loading the reports
      await tester.pumpAndSettle();

      // Verify that no data message is shown
      expect(find.text('No reports available.'), findsOneWidget);

      print("UI test passed: No reports message displayed.");
    });
  });
}
