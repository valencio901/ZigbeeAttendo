import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:aats_app/main.dart'; // Replace with your actual main app file

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group('AttendancePieChart Tests', () {
    testWidgets('Page should load within acceptable time',
        (WidgetTester tester) async {
      final stopwatch = Stopwatch()..start();

      // Start the app and navigate to AttendancePieChart page
      await tester
          .pumpWidget(const MyApp()); // Replace with your main app widget
      await tester.pumpAndSettle(); // Wait until all animations finish

      stopwatch.stop();
      print('Page load time: ${stopwatch.elapsedMilliseconds} ms');

      // Ensure the page loads within 3 seconds
      expect(stopwatch.elapsedMilliseconds, lessThan(3000),
          reason: 'Page should load within 3 seconds');
    });

    test('API Stress Test: Attendance API should handle multiple requests',
        () async {
      const String apiUrl =
          'https://b03d-2409-4042-6e98-bbe2-b9e0-119d-a5b6-90e5.ngrok-free.app/attendance_api.php';

      const int requestCount = 50; // Number of requests to simulate
      List<Future<http.Response>> requests = [];

      // Fire multiple requests simultaneously
      for (int i = 0; i < requestCount; i++) {
        requests.add(http.get(Uri.parse(apiUrl)));
      }

      final responses = await Future.wait(requests);

      for (var response in responses) {
        expect(response.statusCode, 200, reason: 'API should return 200 OK');
        expect(json.decode(response.body), isA<Map>(),
            reason: 'Response should be a valid JSON object');
      }

      print('Stress test passed: $requestCount requests handled successfully.');
    });
  });
}
