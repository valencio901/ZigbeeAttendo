import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:aats_app/Attendance.dart';

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group('AttendancePage Stress Tests', () {
    // 📌 **Page Load Speed Test**
    testWidgets('Page should load within acceptable time',
        (WidgetTester tester) async {
      final stopwatch = Stopwatch()..start();

      // Start the app and navigate to AttendancePage
      await tester.pumpWidget(MaterialApp(
        home: AttendancePage(className: "Class A"), // Use a valid class name
      ));
      await tester.pumpAndSettle(); // Wait until all animations finish

      stopwatch.stop();
      print('Page load time: ${stopwatch.elapsedMilliseconds} ms');

      // Ensure the page loads within 3 seconds
      expect(stopwatch.elapsedMilliseconds, lessThan(3000),
          reason: 'Page should load within 3 seconds');
    });

    // 📌 **API Stress Test**
    test('API Stress Test: Attendance API should handle multiple requests',
        () async {
      const String apiUrl =
          'https://8892-2409-4042-6e98-bbe2-1915-272e-c03e-d5cc.ngrok-free.app/attendance_for.php?className=Class A';

      const int requestCount = 50; // Number of requests to simulate
      List<Future<http.Response>> requests = [];

      // Fire multiple requests simultaneously
      for (int i = 0; i < requestCount; i++) {
        requests.add(http.get(Uri.parse(apiUrl)));
      }

      final responses = await Future.wait(requests);

      for (var response in responses) {
        expect(response.statusCode, 200, reason: 'API should return 200 OK');
        expect(json.decode(response.body), isA<List>(),
            reason: 'Response should be a valid JSON list');
      }

      print('Stress test passed: $requestCount requests handled successfully.');
    });

    // 📌 **UI Stress Test**
    testWidgets('Stress test: Rapid user interactions',
        (WidgetTester tester) async {
      await tester.pumpWidget(MaterialApp(
        home: AttendancePage(className: "Class A"),
      ));
      await tester.pumpAndSettle();

      final Finder dropdownFinder = find.text('RollNo');
      final Finder scrollableList = find.byType(SingleChildScrollView);

      // Tap dropdown rapidly multiple times
      for (int i = 0; i < 10; i++) {
        await tester.tap(dropdownFinder);
        await tester.pumpAndSettle();
      }

      // Rapidly scroll list
      for (int i = 0; i < 5; i++) {
        await tester.fling(scrollableList, const Offset(0, -500), 1000);
        await tester.pumpAndSettle();
      }

      print("UI stress test passed: Handled rapid taps and scrolling.");
    });

    // 📌 **Memory Stress Test**
    testWidgets('Stress test: Handling large attendance data',
        (WidgetTester tester) async {
      final List<Map<String, dynamic>> fakeData = List.generate(
          5000,
          (index) => {
                "rollno": "S$index",
                "attendance": index % 2 == 0 ? "Present" : "Absent",
                "date": "2024-02-10",
                "subject": "Math",
                "classroom": "101"
              });

      await tester.pumpWidget(MaterialApp(
        home: AttendancePage(className: "Class A"),
      ));
      await tester.pumpAndSettle();

      // Simulate loading a large set of data (5000 entries)
      expect(fakeData.length, greaterThan(4000),
          reason: "Large data should be handled smoothly");

      print("Memory stress test passed: App handled large attendance data.");
    });

    // 📌 **Dropdown Functionality Test**
    testWidgets('Dropdown filters should work correctly',
        (WidgetTester tester) async {
      await tester.pumpWidget(MaterialApp(
        home: AttendancePage(className: "Class A"),
      ));
      await tester.pumpAndSettle();

      // Check if the dropdowns exist
      expect(find.text('RollNo'), findsOneWidget);
      expect(find.text('Subject'), findsOneWidget);
      expect(find.text('Date'), findsOneWidget);

      // Tap the roll number dropdown
      await tester.tap(find.text('RollNo'));
      await tester.pumpAndSettle();

      // Select the first available roll number
      if (tester
          .widgetList<DropdownMenuItem<String>>(
              find.byType(DropdownMenuItem<String>))
          .isNotEmpty) {
        await tester.tap(find.byType(DropdownMenuItem<String>).first);
        await tester.pumpAndSettle();
      }
    });
  });
}
