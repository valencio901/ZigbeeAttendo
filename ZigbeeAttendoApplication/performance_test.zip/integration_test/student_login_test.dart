import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:http/http.dart' as http;
import 'package:mockito/mockito.dart';
import 'package:aats_app/student login.dart';
import 'package:aats_app/student data.dart';
import 'package:aats_app/register.dart';


// Mocking the HTTP client
class MockClient extends Mock implements http.Client {}

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group('StudentLoginPage Tests', () {
    // 📌 **UI Test: Page Rendering**
    testWidgets('StudentLoginPage UI elements should be rendered properly',
        (WidgetTester tester) async {
      await tester.pumpWidget(MaterialApp(home: StudentLoginPage()));

      // Verify presence of login-related elements
      expect(find.text('Login'), findsOneWidget);
      expect(find.text('Roll Number'), findsOneWidget);
      expect(find.text('Password'), findsOneWidget);
      expect(find.text('Class'), findsOneWidget);
      expect(find.byType(TextField), findsNWidgets(2)); // Roll No, Password
      expect(find.byType(DropdownButtonFormField), findsOneWidget);
      expect(find.byType(ElevatedButton), findsOneWidget);
      expect(find.text('Register'), findsOneWidget);
    });

    // 📌 **Input Validation Test**
    testWidgets('Should show an error message if fields are empty',
        (WidgetTester tester) async {
      await tester.pumpWidget(MaterialApp(home: StudentLoginPage()));

      // Tap login button without entering credentials
      await tester.tap(find.byType(ElevatedButton));
      await tester.pump();

      // Verify error message appears
      expect(find.text("Please enter roll number, password, and select class."),
          findsOneWidget);
    });

    // 📌 **API Test: Successful Login**
    testWidgets('Successful login should navigate to StudentDataPage',
        (WidgetTester tester) async {
      final client = MockClient();
      when(client.post(any, body: anyNamed('body')))
          .thenAnswer((_) async => http.Response(
                jsonEncode({"status": "success"}),
                200,
              ));

      await tester.pumpWidget(MaterialApp(home: StudentLoginPage()));

      // Enter valid credentials
      await tester.enterText(find.byType(TextField).at(0), "12345");
      await tester.enterText(find.byType(TextField).at(1), "password123");

      // Select class from dropdown
      await tester.tap(find.byType(DropdownButtonFormField));
      await tester.pumpAndSettle();
      await tester.tap(find.text('tybca_a').last);
      await tester.pumpAndSettle();

      // Tap login button
      await tester.tap(find.byType(ElevatedButton));
      await tester.pumpAndSettle();

      // Verify navigation to StudentDataPage
      expect(find.byType(StudentDataPage), findsOneWidget);
    });

    // 📌 **API Test: Incorrect Credentials**
    testWidgets('Incorrect login should display error message',
        (WidgetTester tester) async {
      final client = MockClient();
      when(client.post(any, body: anyNamed('body'))).thenAnswer((_) async =>
          http.Response(
            jsonEncode({"status": "error", "message": "Invalid credentials"}),
            200,
          ));

      await tester.pumpWidget(MaterialApp(home: StudentLoginPage()));

      // Enter incorrect credentials
      await tester.enterText(find.byType(TextField).at(0), "12345");
      await tester.enterText(find.byType(TextField).at(1), "wrongpassword");

      // Select class from dropdown
      await tester.tap(find.byType(DropdownButtonFormField));
      await tester.pumpAndSettle();
      await tester.tap(find.text('tybca_a').last);
      await tester.pumpAndSettle();

      // Tap login button
      await tester.tap(find.byType(ElevatedButton));
      await tester.pumpAndSettle();

      // Verify error message
      expect(find.text("Invalid credentials"), findsOneWidget);
    });

    // 📌 **API Test: Server Failure**
    testWidgets('Server failure should display an error message',
        (WidgetTester tester) async {
      final client = MockClient();
      when(client.post(any, body: anyNamed('body')))
          .thenAnswer((_) async => http.Response('Internal Server Error', 500));

      await tester.pumpWidget(MaterialApp(home: StudentLoginPage()));

      // Enter credentials
      await tester.enterText(find.byType(TextField).at(0), "12345");
      await tester.enterText(find.byType(TextField).at(1), "password123");

      // Select class from dropdown
      await tester.tap(find.byType(DropdownButtonFormField));
      await tester.pumpAndSettle();
      await tester.tap(find.text('tybca_a').last);
      await tester.pumpAndSettle();

      // Tap login button
      await tester.tap(find.byType(ElevatedButton));
      await tester.pumpAndSettle();

      // Verify error message
      expect(
          find.text("Server error. Please try again later."), findsOneWidget);
    });

    // 📌 **Performance Test: Login Response Time**
    testWidgets('Login API should respond within acceptable time',
        (WidgetTester tester) async {
      final stopwatch = Stopwatch()..start();

      final client = MockClient();
      when(client.post(any, body: anyNamed('body')))
          .thenAnswer((_) async => http.Response(
                jsonEncode({"status": "success"}),
                200,
              ));

      await tester.pumpWidget(MaterialApp(home: StudentLoginPage()));

      // Enter credentials
      await tester.enterText(find.byType(TextField).at(0), "12345");
      await tester.enterText(find.byType(TextField).at(1), "password123");

      // Select class from dropdown
      await tester.tap(find.byType(DropdownButtonFormField));
      await tester.pumpAndSettle();
      await tester.tap(find.text('tybca_a').last);
      await tester.pumpAndSettle();

      // Tap login button
      await tester.tap(find.byType(ElevatedButton));
      await tester.pumpAndSettle();

      stopwatch.stop();
      print('Login response time: ${stopwatch.elapsedMilliseconds} ms');

      // Ensure API responds within 2 seconds
      expect(stopwatch.elapsedMilliseconds, lessThan(2000),
          reason: 'Login API should respond within 2 seconds');
    });

    // 📌 **Navigation Test: Register Page**
    testWidgets('Clicking Register should navigate to RegisterPage',
        (WidgetTester tester) async {
      await tester.pumpWidget(MaterialApp(home: StudentLoginPage()));

      // Tap register button
      await tester.tap(find.text('Register'));
      await tester.pumpAndSettle();

      // Verify navigation to RegisterPage
      expect(find.byType(RegisterPage), findsOneWidget);
    });
  });
}
