import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:mockito/mockito.dart';
import 'package:aats_app/student login.dart';
import 'package:aats_app/student data.dart';
import 'package:aats_app/register.dart';

// Mock class for http client
class MockClient extends Mock implements http.Client {}

void main() {
  group('StudentLoginPage Tests', () {
    late MockClient mockClient;
    late StudentLoginPage studentLoginPage;

    setUp(() {
      mockClient = MockClient();
      studentLoginPage = const StudentLoginPage();
    });

    testWidgets('Initial state of StudentLoginPage',
        (WidgetTester tester) async {
      // Build the widget
      await tester.pumpWidget(MaterialApp(home: studentLoginPage));

      // Check if the login fields and buttons are present
      expect(find.text('Login'), findsOneWidget);
      expect(
          find.byType(TextField), findsNWidgets(2)); // For rollno and password
      expect(find.byType(DropdownButtonFormField),
          findsOneWidget); // Class dropdown
      expect(find.byType(ElevatedButton), findsOneWidget); // Login button
    });

    testWidgets('Login failed with empty fields', (WidgetTester tester) async {
      // Build the widget
      await tester.pumpWidget(MaterialApp(home: studentLoginPage));

      // Tap the login button
      await tester.tap(find.byType(ElevatedButton));
      await tester.pump();

      // Check if the error message is shown
      expect(find.text('Please enter roll number, password, and select class.'),
          findsOneWidget);
    });

    testWidgets('Login success when correct credentials are entered',
        (WidgetTester tester) async {
      // Simulate input
      final rollnoController = find.byType(TextField).first;
      final passwordController = find.byType(TextField).at(1);
      final dropdownButton = find.byType(DropdownButtonFormField);

      await tester.pumpWidget(MaterialApp(home: studentLoginPage));

      // Enter roll number and password
      await tester.enterText(rollnoController, '12345');
      await tester.enterText(passwordController, 'password123');
      await tester.tap(dropdownButton);
      await tester.pump();
      await tester.tap(find.text('fybca_a').last);
      await tester.pump();

      // Mocking the response from server
      when(mockClient.post(
        Uri.parse('https://example.com/student_login/login.php'),
        headers: anyNamed('headers'),
        body: anyNamed('body'),
      )).thenAnswer((_) async => http.Response('{"status": "success"}', 200));

      // Tap the login button
      await tester.tap(find.byType(ElevatedButton));
      await tester.pump();

      // Check if the navigation to StudentDataPage happens (you can check widget appearance)
      expect(find.byType(StudentDataPage), findsOneWidget);
    });

    testWidgets('Login failed when wrong credentials are provided',
        (WidgetTester tester) async {
      // Simulate input
      final rollnoController = find.byType(TextField).first;
      final passwordController = find.byType(TextField).at(1);
      final dropdownButton = find.byType(DropdownButtonFormField);

      await tester.pumpWidget(MaterialApp(home: studentLoginPage));

      // Enter roll number and password
      await tester.enterText(rollnoController, 'wrongRollNo');
      await tester.enterText(passwordController, 'wrongPassword');
      await tester.tap(dropdownButton);
      await tester.pump();
      await tester.tap(find.text('fybca_a').last);
      await tester.pump();

      // Mocking the response from server
      when(mockClient.post(
        Uri.parse('https://example.com/student_login/login.php'),
        headers: anyNamed('headers'),
        body: anyNamed('body'),
      )).thenAnswer((_) async => http.Response(
          '{"status": "failure", "message": "Invalid credentials"}', 200));

      // Tap the login button
      await tester.tap(find.byType(ElevatedButton));
      await tester.pump();

      // Check if the error message is shown
      expect(find.text('Invalid credentials'), findsOneWidget);
    });

    testWidgets('Navigating to Register page', (WidgetTester tester) async {
      await tester.pumpWidget(MaterialApp(home: studentLoginPage));

      // Tap the Register button
      await tester.tap(find.text('Register'));
      await tester.pumpAndSettle();

      // Check if RegisterPage is displayed
      expect(find.byType(RegisterPage), findsOneWidget);
    });
  });
}
