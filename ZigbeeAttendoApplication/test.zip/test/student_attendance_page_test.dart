import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:mockito/mockito.dart';
import 'dart:convert';
import 'package:aats_app/student attendence page.dart';

// Mock class for HTTP requests
class MockClient extends Mock implements http.Client {}

void main() {
  group('AttendancePage Tests', () {
    late MockClient mockClient;
    late Widget testWidget;

    setUp(() {
      mockClient = MockClient();
      testWidget = MaterialApp(
        home: AttendancePage(
          subjectName: 'Math',
          rollno: '12345',
          classs: '10A',
        ),
      );
    });

    testWidgets('Shows loading indicator when fetching attendance data',
        (WidgetTester tester) async {
      // Mock HTTP request to delay before returning a response
      when(mockClient.get(Uri.parse(
              'https://8892-2409-4042-6e98-bbe2-1915-272e-c03e-d5cc.ngrok-free.app/custom_student_attendance.php?rollno=12345&subject=Math&start_date=2025-01-01&end_date=2025-01-31&class=10A')))
          .thenAnswer((_) async => http.Response('[]', 200));

      // Build the widget with mock client
      await tester.pumpWidget(testWidget);

      // Trigger a frame
      await tester.pump();

      // Verify the initial loading state
      expect(find.byType(CircularProgressIndicator), findsOneWidget);
    });

    testWidgets('Displays attendance data correctly when fetched',
        (WidgetTester tester) async {
      // Mock HTTP response with some attendance data
      final responseData = json.encode({
        'attendance': [
          {'date': '2025-01-01', 'attendance': 'Present'},
          {'date': '2025-01-02', 'attendance': 'Absent'},
        ],
        'numLectures': 10,
      });
      when(mockClient.get(Uri.parse(
              'https://8892-2409-4042-6e98-bbe2-1915-272e-c03e-d5cc.ngrok-free.app/custom_student_attendance.php?rollno=12345&subject=Math&start_date=2025-01-01&end_date=2025-01-31&class=10A')))
          .thenAnswer((_) async => http.Response(responseData, 200));

      // Build the widget with mock client
      await tester.pumpWidget(testWidget);

      // Trigger a frame
      await tester.pump();

      // Click "Get Attendance Data" button
      await tester.tap(find.text('Get Attendance Data'));
      await tester.pump();

      // Verify the attendance data is displayed in the DataTable
      expect(find.text('2025-01-01'), findsOneWidget);
      expect(find.text('Present'), findsOneWidget);
      expect(find.text('2025-01-02'), findsOneWidget);
      expect(find.text('Absent'), findsOneWidget);
    });

    testWidgets('Shows error message if data fetching fails',
        (WidgetTester tester) async {
      // Mock HTTP response with an error
      when(mockClient.get(Uri.parse(
              'https://8892-2409-4042-6e98-bbe2-1915-272e-c03e-d5cc.ngrok-free.app/custom_student_attendance.php?rollno=12345&subject=Math&start_date=2025-01-01&end_date=2025-01-31&class=10A')))
          .thenAnswer((_) async =>
              http.Response('Failed to load attendance data', 500));

      // Build the widget with mock client
      await tester.pumpWidget(testWidget);

      // Trigger a frame
      await tester.pump();

      // Click "Get Attendance Data" button
      await tester.tap(find.text('Get Attendance Data'));
      await tester.pump();

      // Verify the error message is displayed
      expect(find.text('Failed to load attendance data'), findsOneWidget);
    });

    testWidgets('Displays date picker when start and end dates are selected',
        (WidgetTester tester) async {
      // Build the widget with mock client
      await tester.pumpWidget(testWidget);

      // Trigger a frame
      await tester.pump();

      // Tap on the start date button to show the date picker
      await tester.tap(find.text('Select Start Date'));
      await tester.pumpAndSettle();

      // Verify that the date picker appears
      expect(find.byType(DatePickerDialog), findsOneWidget);

      // Tap on the end date button to show the date picker
      await tester.tap(find.text('Select End Date'));
      await tester.pumpAndSettle();

      // Verify that the date picker appears
      expect(find.byType(DatePickerDialog),
          findsNWidgets(2)); // Expect 2 date pickers
    });

    testWidgets('Handles missing start or end date',
        (WidgetTester tester) async {
      // Build the widget with mock client
      await tester.pumpWidget(testWidget);

      // Trigger a frame
      await tester.pump();

      // Tap on the "Get Attendance Data" button without selecting dates
      await tester.tap(find.text('Get Attendance Data'));
      await tester.pump();

      // Verify that a SnackBar message appears asking for both start and end dates
      expect(find.byType(SnackBar), findsOneWidget);
      expect(
          find.text('Please select both start and end dates'), findsOneWidget);
    });
  });
}
