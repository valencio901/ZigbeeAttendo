import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:http/http.dart' as http;
import 'package:aats_app/TiimeTables.dart';
// Mock the http Client
class MockClient extends Mock implements http.Client {}

void main() {
  group('TimetablePage Tests', () {
    late MockClient mockClient;

    setUp(() {
      mockClient = MockClient();
    });

    testWidgets('TimetablePage displays timetable data',
        (WidgetTester tester) async {
      // Mock the response for timetable data
      when(mockClient.post(Uri.parse(
              'https://8892-2409-4042-6e98-bbe2-1915-272e-c03e-d5cc.ngrok-free.app/fetch_all_timetables.php')))
          .thenAnswer((_) async => http.Response(
              jsonEncode({
                'Monday': [
                  {
                    'id': '1',
                    'lecture': 'Math 101',
                    'start_time': '9:00 AM',
                    'end_time': '10:00 AM',
                    'teacher': 'Mr. Smith',
                    'classroom': 'Room 101'
                  },
                  {
                    'id': '2',
                    'lecture': 'Physics 101',
                    'start_time': '10:00 AM',
                    'end_time': '11:00 AM',
                    'teacher': 'Dr. Johnson',
                    'classroom': 'Room 102'
                  },
                ],
              }),
              200));

      // Create the widget for testing
      await tester.pumpWidget(MaterialApp(
        home: TimetablePage(className: 'your_class_name'),
      ));

      // Wait for the timetable to load
      await tester.pumpAndSettle();

      // Check if the timetable data is displayed
      expect(find.text('Monday'), findsOneWidget);
      expect(find.text('Math 101'), findsOneWidget);
      expect(find.text('9:00 AM'), findsOneWidget);
      expect(find.text('10:00 AM'), findsOneWidget);
      expect(find.text('Mr. Smith'), findsOneWidget);
      expect(find.text('Room 101'), findsOneWidget);
      expect(find.text('Physics 101'), findsOneWidget);
    });

    testWidgets('TimetablePage shows loading indicator while fetching data',
        (WidgetTester tester) async {
      // Mock the response for timetable data
      when(mockClient.post(Uri.parse(
              'https://8892-2409-4042-6e98-bbe2-1915-272e-c03e-d5cc.ngrok-free.app/fetch_all_timetables.php')))
          .thenAnswer((_) async => http.Response(jsonEncode({}), 200));

      // Create the widget for testing
      await tester.pumpWidget(MaterialApp(
        home: TimetablePage(className: 'your_class_name'),
      ));

      // Verify that the loading indicator is shown before data is loaded
      expect(find.byType(CircularProgressIndicator), findsOneWidget);
      await tester.pumpAndSettle();
      // After loading, check that the timetable data appears
      expect(find.text('Monday'), findsOneWidget);
    });

    testWidgets('TimetablePage handles empty timetable',
        (WidgetTester tester) async {
      // Mock the response for timetable data (empty timetable)
      when(mockClient.post(Uri.parse(
              'https://8892-2409-4042-6e98-bbe2-1915-272e-c03e-d5cc.ngrok-free.app/fetch_all_timetables.php')))
          .thenAnswer((_) async => http.Response(jsonEncode({}), 200));

      // Create the widget for testing
      await tester.pumpWidget(MaterialApp(
        home: TimetablePage(className: 'your_class_name'),
      ));

      // Wait for the timetable to load
      await tester.pumpAndSettle();

      // Check if the 'No timetable available' message is displayed when timetable is empty
      expect(find.text('No timetable available'), findsOneWidget);
    });

    testWidgets('TimetablePage update timetable action',
        (WidgetTester tester) async {
      // Mock timetable data
      when(mockClient.post(Uri.parse(
              'https://8892-2409-4042-6e98-bbe2-1915-272e-c03e-d5cc.ngrok-free.app/fetch_all_timetables.php')))
          .thenAnswer((_) async => http.Response(
              jsonEncode({
                'Monday': [
                  {
                    'id': '1',
                    'lecture': 'Math 101',
                    'start_time': '9:00 AM',
                    'end_time': '10:00 AM',
                    'teacher': 'Mr. Smith',
                    'classroom': 'Room 101'
                  },
                ],
              }),
              200));

      // Create the widget for testing
      await tester.pumpWidget(MaterialApp(
        home: TimetablePage(className: 'your_class_name'),
      ));

      // Wait for the timetable to load
      await tester.pumpAndSettle();

      // Open the update dialog by clicking the edit icon
      await tester.tap(find.byIcon(Icons.edit).first);
      await tester.pumpAndSettle();

      // Update the lecture name in the dialog
      await tester.enterText(find.byType(TextField).at(0), 'Updated Math 101');
      await tester.tap(find.text('Save'));
      await tester.pumpAndSettle();

      // Verify the timetable is updated with new lecture name
      expect(find.text('Updated Math 101'), findsOneWidget);
    });

    testWidgets('TimetablePage delete timetable action',
        (WidgetTester tester) async {
      // Mock timetable data
      when(mockClient.post(Uri.parse(
              'https://8892-2409-4042-6e98-bbe2-1915-272e-c03e-d5cc.ngrok-free.app/fetch_all_timetables.php')))
          .thenAnswer((_) async => http.Response(
              jsonEncode({
                'Monday': [
                  {
                    'id': '1',
                    'lecture': 'Math 101',
                    'start_time': '9:00 AM',
                    'end_time': '10:00 AM',
                    'teacher': 'Mr. Smith',
                    'classroom': 'Room 101'
                  },
                ],
              }),
              200));

      // Create the widget for testing
      await tester.pumpWidget(MaterialApp(
        home: TimetablePage(className: 'your_class_name'),
      ));

      // Wait for the timetable to load
      await tester.pumpAndSettle();

      // Delete the timetable entry
      await tester.tap(find.byIcon(Icons.delete).first);
      await tester.pumpAndSettle();

      // Check if the timetable entry is removed
      expect(find.text('Math 101'), findsNothing);
    });
  });
}
