import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:aats_app/ComputerScienceDepartmentPage.dart';

void main() {
  testWidgets('Computer Science Department Page UI Test',
      (WidgetTester tester) async {
    // Build the ComputerScienceDepartmentPage widget
    await tester.pumpWidget(MaterialApp(home: ComputerScienceDepartmentPage()));

    // Verify the presence of the AppBar title
    expect(find.text('Class'), findsOneWidget);

    // Verify the presence of class buttons
    expect(find.text('FYBCA A'), findsOneWidget);
    expect(find.text('FYBCA B'), findsOneWidget);
    expect(find.text('SYBCA A'), findsOneWidget);
    expect(find.text('SYBCA B'), findsOneWidget);
    expect(find.text('TYBCA A'), findsOneWidget);
    expect(find.text('TYBCA B'), findsOneWidget);
    expect(find.text('FYBVOC A'), findsOneWidget);
    expect(find.text('FYBVOC B'), findsOneWidget);
    expect(find.text('SYBVOC A'), findsOneWidget);
    expect(find.text('SYBVOC B'), findsOneWidget);
    expect(find.text('TYBVOC A'), findsOneWidget);
    expect(find.text('TYBVOC B'), findsOneWidget);

    // Verify the presence of buttons with bar chart icons
    expect(find.byIcon(Icons.bar_chart), findsWidgets);
  });
}
