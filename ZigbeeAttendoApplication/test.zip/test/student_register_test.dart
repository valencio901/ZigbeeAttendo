import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:aats_app/register.dart';

void main() {
  testWidgets('Register Page UI Test', (WidgetTester tester) async {
    // Build the RegisterPage widget
    await tester.pumpWidget(MaterialApp(home: RegisterPage()));

    // Verify the presence of the Register title
    expect(find.text('Register'), findsOneWidget);

    // Verify the presence of input fields
    expect(find.byType(TextField), findsNWidgets(6));
    expect(find.text('Roll No'), findsOneWidget);
    expect(find.text('Name'), findsOneWidget);
    expect(find.text('Class'), findsOneWidget);
    expect(find.text('Class Room'), findsOneWidget);
    expect(find.text('College'), findsOneWidget);
    expect(find.text('Password'), findsOneWidget);

    // Verify the presence of the Register button
    expect(find.text('Register'), findsOneWidget);

    // Tap the Register button
    await tester.tap(find.text('Register'));
    await tester.pump();
  });
}
