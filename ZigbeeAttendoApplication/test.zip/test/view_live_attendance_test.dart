import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:aats_app/live.dart';

void main() {
  testWidgets('Serial Data Screen UI Test', (WidgetTester tester) async {
    // Build the SerialDataScreen widget
    await tester.pumpWidget(MaterialApp(home: SerialDataScreen()));

    // Verify the presence of the AppBar title
    expect(find.text('ESP32 Serial Monitor'), findsOneWidget);

    // Verify the presence of initial serial output text
    expect(find.textContaining('Serial Output:'), findsOneWidget);
  });
}
