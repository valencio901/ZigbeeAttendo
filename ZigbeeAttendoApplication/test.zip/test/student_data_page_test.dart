import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:mockito/mockito.dart';
import 'package:aats_app/student attendence page.dart'; // Correct the file name if necessary
import 'package:aats_app/student data.dart'; // Correct the file name if necessary
import 'package:fl_chart/fl_chart.dart';

// Mock class for HTTP requests
class MockClient extends Mock implements http.Client {}

void main() {
  group('StudentDataPage Tests', () {
    late MockClient mockClient;
    late Widget testWidget;

    setUp(() {
      mockClient = MockClient();
      testWidget = MaterialApp(
        home: StudentDataPage(
          rollno: '12345',
          classs: '10A',
        ),
      );
    });

    testWidgets('Shows loading indicator while fetching student data',
        (WidgetTester tester) async {
      // Mock HTTP requests for fetching student data
      when(mockClient.post(Uri.parse(
              'https://8bc4-2409-4042-6ec9-1f2b-91fb-986-2aae-1a64.ngrok-free.app/get_student_data.php')))
          .thenAnswer((_) async => http.Response(
              '{"status": "success", "student": {"name": "John Doe"}}', 200));

      when(mockClient.get(Uri.parse(
              'https://8bc4-2409-4042-6ec9-1f2b-91fb-986-2aae-1a64.ngrok-free.app/fetch_students_attendance.php')))
          .thenAnswer((_) async =>
              http.Response('{"status": "success", "timetable": []}', 200));

      await tester.pumpWidget(testWidget);
      await tester.pump();

      // Verify that the loading indicator is visible
      expect(find.byType(CircularProgressIndicator), findsOneWidget);
    });

    testWidgets('Displays student data correctly when fetched',
        (WidgetTester tester) async {
      // Mock HTTP response for student data
      final studentDataResponse =
          '{"status": "success", "student": {"name": "John Doe", "classroom": "A1", "college": "XYZ College"}}';
      when(mockClient.post(Uri.parse(
              'https://8bc4-2409-4042-6ec9-1f2b-91fb-986-2aae-1a64.ngrok-free.app/get_student_data.php')))
          .thenAnswer((_) async => http.Response(studentDataResponse, 200));

      // Mock response for timetable data
      final timetableResponse = '{"status": "success", "timetable": []}';
      when(mockClient.get(Uri.parse(
              'https://8bc4-2409-4042-6ec9-1f2b-91fb-986-2aae-1a64.ngrok-free.app/fetch_students_attendance.php')))
          .thenAnswer((_) async => http.Response(timetableResponse, 200));

      await tester.pumpWidget(testWidget);
      await tester.pump();

      // Verify that student data is displayed
      expect(find.text('John Doe'), findsOneWidget);
      expect(find.text('Roll No: 12345'), findsOneWidget);
      expect(find.text('Class: 10A'), findsOneWidget);
      expect(find.text('Classroom: A1'), findsOneWidget);
      expect(find.text('College: XYZ College'), findsOneWidget);
    });

    testWidgets('Displays subject buttons correctly',
        (WidgetTester tester) async {
      // Mock subject names response
      final subjectResponse =
          '{"status": "success", "subjects": ["Math", "Science", "English"]}';
      when(mockClient.get(Uri.parse(
              'https://8892-2409-4042-6e98-bbe2-1915-272e-c03e-d5cc.ngrok-free.app/get_students_subjects.php')))
          .thenAnswer((_) async => http.Response(subjectResponse, 200));

      await tester.pumpWidget(testWidget);
      await tester.pump();

      // Verify that subject buttons are displayed
      expect(find.text('Math'), findsOneWidget);
      expect(find.text('Science'), findsOneWidget);
      expect(find.text('English'), findsOneWidget);
    });

    testWidgets('Navigates to AttendancePage when subject is clicked',
        (WidgetTester tester) async {
      // Mock subject names response
      final subjectResponse =
          '{"status": "success", "subjects": ["Math", "Science", "English"]}';
      when(mockClient.get(Uri.parse(
              'https://8892-2409-4042-6e98-bbe2-1915-272e-c03e-d5cc.ngrok-free.app/get_students_subjects.php')))
          .thenAnswer((_) async => http.Response(subjectResponse, 200));

      await tester.pumpWidget(testWidget);
      await tester.pump();

      // Tap the "Math" subject button
      await tester.tap(find.text('Math'));
      await tester.pumpAndSettle();

      // Verify that it navigated to the AttendancePage
      expect(find.byType(AttendancePage), findsOneWidget);
    });

    testWidgets('Displays PieChart for attendance',
        (WidgetTester tester) async {
      // Mock timetable response with attendance data
      final timetableResponse =
          '{"status": "success", "timetable": [{"attendance": "Present"}, {"attendance": "Absent"}]}';
      when(mockClient.get(Uri.parse(
              'https://8bc4-2409-4042-6ec9-1f2b-91fb-986-2aae-1a64.ngrok-free.app/fetch_students_attendance.php')))
          .thenAnswer((_) async => http.Response(timetableResponse, 200));

      await tester.pumpWidget(testWidget);
      await tester.pump();

      // Verify that the PieChart is displayed
      expect(find.byType(PieChart), findsOneWidget);
    });
  });
}
