import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:aats_app/teachers data.dart';

// Create a mock class for http.Client to simulate network requests
class MockClient extends Mock implements http.Client {}

void main() {
  group('TeacherDataPage Tests', () {
    late MockClient mockClient;

    setUp(() {
      mockClient = MockClient();
    });

    testWidgets('TeacherDataPage shows teacher data',
        (WidgetTester tester) async {
      // Mock response for teacher data
      when(mockClient.get(Uri.parse(
              'https://8892-2409-4042-6e98-bbe2-1915-272e-c03e-d5cc.ngrok-free.app/fetch_teacher_details.php?teacherName=JohnDoe')))
          .thenAnswer((_) async => http.Response(
              jsonEncode({
                'teacher_name': 'John Doe',
                'phone_number': '1234567890',
                'address': '123 Main St',
              }),
              200));

      // Create the widget for testing
      await tester.pumpWidget(MaterialApp(
        home: TeacherDataPage(teacherName: 'JohnDoe'),
      ));

      // Wait for the future to resolve
      await tester.pumpAndSettle();

      // Check if the teacher's name is displayed
      expect(find.text('John Doe'), findsOneWidget);
      expect(find.text('Phone No: 1234567890'), findsOneWidget);
      expect(find.text('Address: 123 Main St'), findsOneWidget);
    });

    testWidgets('TeacherDataPage shows error when no data is available',
        (WidgetTester tester) async {
      // Mock response for teacher data with an error
      when(mockClient.get(Uri.parse(
              'https://8892-2409-4042-6e98-bbe2-1915-272e-c03e-d5cc.ngrok-free.app/fetch_teacher_details.php?teacherName=JohnDoe')))
          .thenAnswer((_) async => http.Response('{"error": "No data"}', 500));

      // Create the widget for testing
      await tester.pumpWidget(MaterialApp(
        home: TeacherDataPage(teacherName: 'JohnDoe'),
      ));

      // Wait for the future to resolve
      await tester.pumpAndSettle();

      // Check if the error message is shown
      expect(find.text('Error: Exception: Failed to load teacher data'),
          findsOneWidget);
    });

    testWidgets('TeacherDataPage shows loading indicator while fetching data',
        (WidgetTester tester) async {
      // Mock response for teacher data
      when(mockClient.get(Uri.parse(
              'https://8892-2409-4042-6e98-bbe2-1915-272e-c03e-d5cc.ngrok-free.app/fetch_teacher_details.php?teacherName=JohnDoe')))
          .thenAnswer((_) async => http.Response(
              jsonEncode({
                'teacher_name': 'John Doe',
                'phone_number': '1234567890',
                'address': '123 Main St',
              }),
              200));

      // Create the widget for testing
      await tester.pumpWidget(MaterialApp(
        home: TeacherDataPage(teacherName: 'JohnDoe'),
      ));

      // Verify that the loading indicator is shown before data is loaded
      expect(find.byType(CircularProgressIndicator), findsOneWidget);
      await tester.pumpAndSettle();
      // After loading, check that the teacher's data appears
      expect(find.text('John Doe'), findsOneWidget);
    });

    testWidgets('TeacherDataPage displays class data correctly',
        (WidgetTester tester) async {
      // Mock the response for classes
      when(mockClient.get(Uri.parse(
              'https://8892-2409-4042-6e98-bbe2-1915-272e-c03e-d5cc.ngrok-free.app/fetch_classes.php?teacherName=JohnDoe')))
          .thenAnswer((_) async => http.Response(
              jsonEncode({
                'success': true,
                'data': [
                  {
                    'classroom': 'Room 101',
                    'subject': 'Math',
                    'time': '10:00 AM'
                  },
                  {
                    'classroom': 'Room 102',
                    'subject': 'Science',
                    'time': '12:00 PM'
                  },
                ],
              }),
              200));

      // Create the widget for testing
      await tester.pumpWidget(MaterialApp(
        home: TeacherDataPage(teacherName: 'JohnDoe'),
      ));

      // Wait for data to load
      await tester.pumpAndSettle();

      // Check if class data is displayed
      expect(find.text('Room 101'), findsOneWidget);
      expect(find.text('Math'), findsOneWidget);
      expect(find.text('10:00 AM'), findsOneWidget);
      expect(find.text('Room 102'), findsOneWidget);
      expect(find.text('Science'), findsOneWidget);
      expect(find.text('12:00 PM'), findsOneWidget);
    });
  });
}
