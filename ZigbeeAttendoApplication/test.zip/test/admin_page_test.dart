import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:aats_app/admin.dart';

void main() {
  testWidgets('Attendance Pie Chart UI Test', (WidgetTester tester) async {
    // Build the AttendancePieChart widget
    await tester.pumpWidget(MaterialApp(home: AttendancePieChart()));

    // Verify the presence of the AppBar title
    expect(find.text('Admin'), findsOneWidget);

    // Verify the presence of key text elements
    expect(find.text('Total Students:'), findsOneWidget);
    expect(find.text('Present:'), findsOneWidget);
    expect(find.text('Faculty Attendance'), findsOneWidget);
    expect(find.text('Classes with Highest Attendance'), findsOneWidget);
    expect(find.text('Classes with Lowest Attendance'), findsOneWidget);

    // Verify the presence of icons in the drawer
    expect(find.byIcon(Icons.report), findsWidgets);
    expect(find.byIcon(Icons.schedule), findsOneWidget);
    expect(find.byIcon(Icons.notifications_active_outlined), findsOneWidget);
    expect(find.byIcon(Icons.settings), findsOneWidget);
    expect(find.byIcon(Icons.class_outlined), findsOneWidget);
  });
}
