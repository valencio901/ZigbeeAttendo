import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:mockito/mockito.dart';
import 'package:aats_app/teacher view student attendence.dart';

// Mock class for HTTP client
class MockClient extends Mock implements http.Client {}

void main() {
  group('TeacherViewAttendancePage Tests', () {
    late MockClient mockClient;
    late TeacherViewAttendancePage teacherViewAttendancePage;

    // Setup the mock client and teacher view attendance page
    setUp(() {
      mockClient = MockClient();
      teacherViewAttendancePage =
          TeacherViewAttendancePage(teacherName: 'Mr. John');
    });

    testWidgets('Initial state of TeacherViewAttendancePage (Loading)',
        (WidgetTester tester) async {
      // Build the widget
      await tester.pumpWidget(MaterialApp(home: teacherViewAttendancePage));

      // Check if the loading indicator is shown
      expect(find.byType(CircularProgressIndicator), findsOneWidget);
    });

    testWidgets('No attendance records found', (WidgetTester tester) async {
      // Simulate the API response with no attendance data
      when(mockClient.get(Uri.parse(
              'https://8892-2409-4042-6e98-bbe2-1915-272e-c03e-d5cc.ngrok-free.app/teacher_view_student.php?teacherName=Mr.%20John')))
          .thenAnswer(
              (_) async => http.Response('{"attendanceRecords": []}', 200));

      // Build the widget
      await tester.pumpWidget(MaterialApp(home: teacherViewAttendancePage));

      // Wait for the widget to update after the HTTP request is completed
      await tester.pumpAndSettle();

      // Check if the "No attendance records found" message is displayed
      expect(find.text("No attendance records found."), findsOneWidget);
    });

    testWidgets('Display attendance data in a DataTable',
        (WidgetTester tester) async {
      // Simulate the API response with attendance data
      final responseJson = '''
      {
        "attendanceRecords": [
          {
            "rollno": "12345",
            "date": "2025-02-10",
            "subject": "Math",
            "time": "9:00 AM",
            "classroom": "A1",
            "attendance": "Present",
            "database": "sybca_a"
          }
        ]
      }
      ''';

      when(mockClient.get(Uri.parse(
              'https://8892-2409-4042-6e98-bbe2-1915-272e-c03e-d5cc.ngrok-free.app/teacher_view_student.php?teacherName=Mr.%20John')))
          .thenAnswer((_) async => http.Response(responseJson, 200));

      // Build the widget
      await tester.pumpWidget(MaterialApp(home: teacherViewAttendancePage));

      // Wait for the widget to update after the HTTP request is completed
      await tester.pumpAndSettle();

      // Check if the attendance data is displayed correctly in the DataTable
      expect(find.text('12345'), findsOneWidget); // Roll No
      expect(find.text('2025-02-10'), findsOneWidget); // Date
      expect(find.text('Math'), findsOneWidget); // Subject
      expect(find.text('9:00 AM'), findsOneWidget); // Time
      expect(find.text('A1'), findsOneWidget); // Classroom
      expect(find.text('Present'), findsOneWidget); // Attendance
      expect(find.text('sybca_a'), findsOneWidget); // Class
    });

    testWidgets('Network error handling in TeacherViewAttendancePage',
        (WidgetTester tester) async {
      // Simulate a network error
      when(mockClient.get(Uri.parse(
              'https://8892-2409-4042-6e98-bbe2-1915-272e-c03e-d5cc.ngrok-free.app/teacher_view_student.php?teacherName=Mr.%20John')))
          .thenThrow(Exception('Network error'));

      // Build the widget
      await tester.pumpWidget(MaterialApp(home: teacherViewAttendancePage));

      // Wait for the widget to update after the HTTP request fails
      await tester.pumpAndSettle();

      // Check if the loading indicator is not shown and an error is handled (optional, adjust based on implementation)
      expect(find.byType(CircularProgressIndicator),
          findsNothing); // No loading spinner
    });
  });
}
