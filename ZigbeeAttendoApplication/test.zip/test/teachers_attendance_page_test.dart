import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:mockito/mockito.dart';
import 'package:aats_app/teachers attendence.dart';

// Mock class for HTTP client
class MockClient extends Mock implements http.Client {}

void main() {
  group('TeacherAttendance Tests', () {
    late MockClient mockClient;
    late TeacherAttendance teacherAttendance;

    // Setup the mock client and TeacherAttendance widget
    setUp(() {
      mockClient = MockClient();
      teacherAttendance = TeacherAttendance(teacherName: 'Mr. John');
    });

    testWidgets('Initial loading state (loading spinner)',
        (WidgetTester tester) async {
      // Simulate the widget build
      await tester.pumpWidget(MaterialApp(home: teacherAttendance));

      // Check if the CircularProgressIndicator is displayed
      expect(find.byType(CircularProgressIndicator), findsOneWidget);
    });

    testWidgets('No attendance data found', (WidgetTester tester) async {
      // Simulate an empty attendance data response
      when(mockClient.get(Uri.parse(
              'https://8892-2409-4042-6e98-bbe2-1915-272e-c03e-d5cc.ngrok-free.app/get_teacher_attendance.php?teacher_name=Mr.%20John')))
          .thenAnswer((_) async => http.Response('[]', 200));

      // Build the widget
      await tester.pumpWidget(MaterialApp(home: teacherAttendance));

      // Wait for the widget to update after the HTTP request is completed
      await tester.pumpAndSettle();

      // Check if "No attendance data found." message is displayed
      expect(find.text('No attendance data found.'), findsOneWidget);
    });

    testWidgets('Error state when fetching attendance data',
        (WidgetTester tester) async {
      // Simulate a network error
      when(mockClient.get(Uri.parse(
              'https://8892-2409-4042-6e98-bbe2-1915-272e-c03e-d5cc.ngrok-free.app/get_teacher_attendance.php?teacher_name=Mr.%20John')))
          .thenThrow(Exception('Network error'));

      // Build the widget
      await tester.pumpWidget(MaterialApp(home: teacherAttendance));

      // Wait for the widget to update after the error occurs
      await tester.pumpAndSettle();

      // Check if the error message is displayed
      expect(find.text('Error: Network error'), findsOneWidget);
    });

    testWidgets('Display attendance data in DataTable',
        (WidgetTester tester) async {
      // Simulate the API response with attendance data
      final responseJson = '''
      [
        {
          "teacher_name": "Mr. John",
          "attendance": "Present",
          "lecture_time": "9:00 AM",
          "classroom": "A1"
        },
        {
          "teacher_name": "Mr. John",
          "attendance": "Absent",
          "lecture_time": "11:00 AM",
          "classroom": "B1"
        }
      ]
      ''';

      when(mockClient.get(Uri.parse(
              'https://8892-2409-4042-6e98-bbe2-1915-272e-c03e-d5cc.ngrok-free.app/get_teacher_attendance.php?teacher_name=Mr.%20John')))
          .thenAnswer((_) async => http.Response(responseJson, 200));

      // Build the widget
      await tester.pumpWidget(MaterialApp(home: teacherAttendance));

      // Wait for the widget to update after the HTTP request is completed
      await tester.pumpAndSettle();

      // Check if the attendance data is displayed in the DataTable
      expect(find.text('Mr. John'),
          findsNWidgets(2)); // Teacher name appears in both rows
      expect(find.text('Present'),
          findsOneWidget); // Attendance status for first row
      expect(find.text('Absent'),
          findsOneWidget); // Attendance status for second row
      expect(find.text('9:00 AM'),
          findsOneWidget); // Lecture time for the first row
      expect(find.text('11:00 AM'),
          findsOneWidget); // Lecture time for the second row
      expect(find.text('A1'), findsOneWidget); // Classroom for the first row
      expect(find.text('B1'), findsOneWidget); // Classroom for the second row
    });
  });
}
