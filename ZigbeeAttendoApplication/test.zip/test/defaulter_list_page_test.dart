import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:aats_app/DangerListPage.dart';

void main() {
  testWidgets('Danger List Page UI Test', (WidgetTester tester) async {
    // Build the DangerListPage widget with a test class name
    await tester
        .pumpWidget(MaterialApp(home: DangerListPage(className: 'Test Class')));

    // Verify the presence of the AppBar title
    expect(find.text('Defaulter List for Class: Test Class'), findsOneWidget);

    // Verify loading indicator appears while fetching data
    expect(find.byType(CircularProgressIndicator), findsOneWidget);

    // Wait for the UI to rebuild after data load
    await tester.pumpAndSettle();

    // Check for error message or empty state text
    expect(
        find.textContaining('Failed to load danger list data'), findsNothing);
    expect(find.textContaining('No students in danger list'), findsNothing);

    // Verify presence of DataTable
    expect(find.byType(DataTable), findsOneWidget);
  });
}
