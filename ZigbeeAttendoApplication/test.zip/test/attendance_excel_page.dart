import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:aats_app/attendance_excel.dart';

void main() {
  testWidgets('Attendance Excel Page UI Test', (WidgetTester tester) async {
    // Build the AttendanceExcelPage widget
    await tester.pumpWidget(MaterialApp(home: AttendanceExcelPage()));

    // Verify the presence of the AppBar title
    expect(find.text('Attendance Excel Files'), findsOneWidget);

    // Verify loading indicator appears while fetching data
    expect(find.byType(CircularProgressIndicator), findsOneWidget);

    // Wait for the UI to rebuild after data load
    await tester.pumpAndSettle();

    // Check for error message or empty state text
    expect(find.textContaining('Failed to load files'), findsNothing);
    expect(find.textContaining('No Excel files available'), findsNothing);

    // Verify presence of file list items (if available)
    expect(find.byType(ListTile), findsWidgets);
    expect(find.byIcon(Icons.download), findsWidgets);
  });
}
