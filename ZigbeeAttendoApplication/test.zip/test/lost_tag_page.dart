import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:aats_app/Lost Tag.dart';

void main() {
  testWidgets('Lost Tag Page UI Test', (WidgetTester tester) async {
    // Build the LostTagPage widget
    await tester.pumpWidget(MaterialApp(home: LostTagPage()));

    // Verify the presence of the AppBar title
    expect(find.text('Lost Tag'), findsOneWidget);

    // Verify the presence of input fields
    expect(find.byType(TextField), findsNWidgets(4));
    expect(find.text('Roll No'), findsOneWidget);
    expect(find.text('Class'), findsOneWidget);
    expect(find.text('Classroom'), findsOneWidget);
    expect(find.text('Report'), findsOneWidget);

    // Verify the presence of the report button
    expect(find.text('Report to Office'), findsOneWidget);

    // Tap the report button and trigger the alert dialog
    await tester.tap(find.text('Report to Office'));
    await tester.pump();

    // Verify the presence of the alert dialog
    expect(find.text('Report Status'), findsOneWidget);
    expect(find.text('Reported to the office'), findsOneWidget);
    expect(find.text('OK'), findsOneWidget);
  });
}
