import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:aats_app/TimeTableOf.dart';
import 'package:aats_app/TiimeTables.dart';

void main() {
  group('Timetableof Page Tests', () {
    testWidgets('Timetableof page UI loads correctly',
        (WidgetTester tester) async {
      // Build the Timetableof widget
      await tester.pumpWidget(MaterialApp(
        home: Timetableof(),
      ));

      // Wait for the UI to load
      await tester.pumpAndSettle();

      // Check if the title "SELECT CLASS" is displayed
      expect(find.text('SELECT CLASS'), findsOneWidget);

      // Check if the buttons for classes are displayed
      expect(find.text('FYBCA A'), findsOneWidget);
      expect(find.text('FYBCA B'), findsOneWidget);
      expect(find.text('SYBCA A'), findsOneWidget);
      expect(find.text('SYBCA B'), findsOneWidget);
      expect(find.text('TYBCA A'), findsOneWidget);
      expect(find.text('TYBCA B'), findsOneWidget);
      expect(find.text('FYBVOC A'), findsOneWidget);
      expect(find.text('FYBVOC B'), findsOneWidget);
      expect(find.text('SYBVOC A'), findsOneWidget);
      expect(find.text('SYBVOC B'), findsOneWidget);
      expect(find.text('TYBVOC A'), findsOneWidget);
      expect(find.text('TYBVOC B'), findsOneWidget);

      // Verify that buttons are displayed with the right labels
      expect(find.byIcon(Icons.calendar_today),
          findsNWidgets(12)); // Since there are 12 buttons with this icon
    });

    testWidgets('Navigating to TimetablePage when class button is clicked',
        (WidgetTester tester) async {
      // Create the widget for testing
      await tester.pumpWidget(MaterialApp(
        home: Timetableof(),
      ));

      // Wait for the page to settle
      await tester.pumpAndSettle();

      // Tap the 'FYBCA A' button
      await tester.tap(find.text('FYBCA A'));
      await tester.pumpAndSettle(); // Wait for the navigation to happen

      // Verify that we are navigating to the TimetablePage and the class name is passed correctly
      expect(find.byType(MyApp),
          findsOneWidget); // Ensure TimetablePage (MyApp) is shown
      expect(find.text('FYBCA A'),
          findsOneWidget); // Check that class name is displayed in the TimetablePage
    });

    testWidgets('Button presses navigate correctly',
        (WidgetTester tester) async {
      // Create the widget for testing
      await tester.pumpWidget(MaterialApp(
        home: Timetableof(),
      ));

      // Wait for the page to settle
      await tester.pumpAndSettle();

      // Tap on the 'SYBCA A' button
      await tester.tap(find.text('SYBCA A'));
      await tester.pumpAndSettle();

      // Verify that we navigated to the correct TimetablePage
      expect(find.byType(MyApp), findsOneWidget);
      expect(find.text('SYBCA A'), findsOneWidget);
    });
  });
}
