import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:mockito/mockito.dart';
import 'dart:convert';
import 'package:aats_app/reports.dart';

// Mock class for HTTP requests
class MockClient extends Mock implements http.Client {}

void main() {
  group('ReportPage Tests', () {
    late MockClient mockClient;

    setUp(() {
      mockClient = MockClient();
    });

    testWidgets('Shows loading indicator when data is being fetched',
        (WidgetTester tester) async {
      // Mock the HTTP request to delay before returning a response
      when(mockClient.get(Uri.parse(
              'https://8892-2409-4042-6e98-bbe2-1915-272e-c03e-d5cc.ngrok-free.app/get_reports.php')))
          .thenAnswer((_) async => http.Response('[]', 200));

      // Build the ReportPage widget with the mock client
      await tester.pumpWidget(MaterialApp(
        home: ReportPage(),
      ));

      // Trigger a frame.
      await tester.pump();

      // Verify the loading indicator is visible
      expect(find.byType(CircularProgressIndicator), findsOneWidget);
    });

    testWidgets('Shows reports when data is fetched successfully',
        (WidgetTester tester) async {
      // Mock HTTP response with a list of reports
      final responseData = json.encode([
        {
          'rollno': '123',
          'class': 'Math',
          'classroom': 'A1',
          'report': 'Good performance'
        },
        {
          'rollno': '124',
          'class': 'Science',
          'classroom': 'B1',
          'report': 'Needs improvement'
        },
      ]);
      when(mockClient.get(Uri.parse(
              'https://8892-2409-4042-6e98-bbe2-1915-272e-c03e-d5cc.ngrok-free.app/get_reports.php')))
          .thenAnswer((_) async => http.Response(responseData, 200));

      // Build the ReportPage widget with the mock client
      await tester.pumpWidget(MaterialApp(
        home: ReportPage(),
      ));

      // Trigger a frame
      await tester.pump();

      // Verify the reports are displayed
      expect(find.text('Roll No: 123'), findsOneWidget);
      expect(find.text('Class: Math'), findsOneWidget);
      expect(find.text('Classroom: A1'), findsOneWidget);
      expect(find.text('Report: Good performance'), findsOneWidget);

      expect(find.text('Roll No: 124'), findsOneWidget);
      expect(find.text('Class: Science'), findsOneWidget);
      expect(find.text('Classroom: B1'), findsOneWidget);
      expect(find.text('Report: Needs improvement'), findsOneWidget);
    });

    testWidgets('Shows error message when the data fetch fails',
        (WidgetTester tester) async {
      // Mock HTTP failure response
      when(mockClient.get(Uri.parse(
              'https://8892-2409-4042-6e98-bbe2-1915-272e-c03e-d5cc.ngrok-free.app/get_reports.php')))
          .thenAnswer(
              (_) async => http.Response('Failed to load reports', 500));

      // Build the ReportPage widget with the mock client
      await tester.pumpWidget(MaterialApp(
        home: ReportPage(),
      ));

      // Trigger a frame
      await tester.pump();

      // Verify the error message is displayed
      expect(find.text('Failed to load reports. Please try again later.'),
          findsOneWidget);
    });

    testWidgets('Shows no reports message when no data is available',
        (WidgetTester tester) async {
      // Mock empty response
      when(mockClient.get(Uri.parse(
              'https://8892-2409-4042-6e98-bbe2-1915-272e-c03e-d5cc.ngrok-free.app/get_reports.php')))
          .thenAnswer((_) async => http.Response('[]', 200));

      // Build the ReportPage widget with the mock client
      await tester.pumpWidget(MaterialApp(
        home: ReportPage(),
      ));

      // Trigger a frame
      await tester.pump();

      // Verify the no reports message is displayed
      expect(find.text('No reports available.'), findsOneWidget);
    });
  });
}
