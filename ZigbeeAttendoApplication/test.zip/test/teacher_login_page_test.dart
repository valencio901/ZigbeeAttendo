import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:mockito/mockito.dart';
import 'package:aats_app/teacher login.dart';
import 'package:aats_app/teachers data.dart';
import 'package:aats_app/teacher register page.dart';

// Mock class for HTTP client
class MockClient extends Mock implements http.Client {}

void main() {
  group('TeacherLoginPage Tests', () {
    late MockClient mockClient;
    late TeacherLoginPage teacherLoginPage;

    setUp(() {
      mockClient = MockClient();
      teacherLoginPage = const TeacherLoginPage();
    });

    testWidgets('Initial state of TeacherLoginPage',
        (WidgetTester tester) async {
      // Build the widget
      await tester.pumpWidget(MaterialApp(home: teacherLoginPage));

      // Check if the login fields and buttons are present
      expect(find.text('Login'), findsOneWidget);
      expect(find.byType(TextField),
          findsNWidgets(2)); // For teacher name and password
      expect(find.byType(ElevatedButton), findsOneWidget); // Login button
    });

    testWidgets('Login failed with empty fields', (WidgetTester tester) async {
      // Build the widget
      await tester.pumpWidget(MaterialApp(home: teacherLoginPage));

      // Tap the login button
      await tester.tap(find.byType(ElevatedButton));
      await tester.pump();

      // Check if the error message is shown
      expect(find.text('Please enter both Teacher ID and Password.'),
          findsOneWidget);
    });

    testWidgets('Login success when correct credentials are entered',
        (WidgetTester tester) async {
      // Simulate input
      final nameField = find.byType(TextField).first;
      final passwordField = find.byType(TextField).at(1);

      await tester.pumpWidget(MaterialApp(home: teacherLoginPage));

      // Enter teacher name and password
      await tester.enterText(nameField, 'teacher123');
      await tester.enterText(passwordField, 'password123');

      // Mocking the response from server
      when(mockClient.post(
        Uri.parse('https://url.com/teacher_login/login.php'),
        body: anyNamed('body'),
      )).thenAnswer((_) async => http.Response('{"success": true}', 200));

      // Tap the login button
      await tester.tap(find.byType(ElevatedButton));
      await tester.pump();

      // Check if the navigation to TeacherDataPage happens (you can check widget appearance)
      expect(find.byType(TeacherDataPage), findsOneWidget);
    });

    testWidgets('Login failed with incorrect credentials',
        (WidgetTester tester) async {
      // Simulate input
      final nameField = find.byType(TextField).first;
      final passwordField = find.byType(TextField).at(1);

      await tester.pumpWidget(MaterialApp(home: teacherLoginPage));

      // Enter teacher name and password
      await tester.enterText(nameField, 'wrongTeacher');
      await tester.enterText(passwordField, 'wrongPassword');

      // Mocking the response from server
      when(mockClient.post(
        Uri.parse('https://url.com/teacher_login/login.php'),
        body: anyNamed('body'),
      )).thenAnswer((_) async => http.Response(
          '{"success": false, "message": "Invalid credentials"}', 200));

      // Tap the login button
      await tester.tap(find.byType(ElevatedButton));
      await tester.pump();

      // Check if the error message is shown
      expect(find.text('Invalid credentials'), findsOneWidget);
    });

    testWidgets('Navigating to Teacher Register page',
        (WidgetTester tester) async {
      await tester.pumpWidget(MaterialApp(home: teacherLoginPage));

      // Tap the Register button
      await tester.tap(find.text('Register'));
      await tester.pumpAndSettle();

      // Check if TeacherRegisterPage is displayed
      expect(find.byType(TeacherRegisterPage), findsOneWidget);
    });
  });
}
