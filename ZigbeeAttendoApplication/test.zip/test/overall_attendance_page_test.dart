import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:aats_app/Attendance.dart';
import 'package:fl_chart/fl_chart.dart';

void main() {
  testWidgets('Attendance Page UI Test', (WidgetTester tester) async {
    // Build the AttendancePage widget with a test class name
    await tester
        .pumpWidget(MaterialApp(home: AttendancePage(className: 'Test Class')));

    // Verify the presence of the AppBar title
    expect(find.text('Test Class'), findsOneWidget);

    // Verify loading indicator appears while fetching data
    expect(find.byType(CircularProgressIndicator), findsOneWidget);

    // Wait for the UI to rebuild after data load
    await tester.pumpAndSettle();

    // Check for error message or empty state text
    expect(find.textContaining('Failed to load files'), findsNothing);
    expect(find.textContaining('No data available'), findsNothing);

    // Verify presence of key UI elements
    expect(find.textContaining('Total Students of class'), findsOneWidget);
    expect(
        find.textContaining('Total Students attended today'), findsOneWidget);
    expect(find.textContaining('Total Students attended all lectures'),
        findsOneWidget);

    // Verify presence of pie chart
    expect(find.byType(PieChart), findsOneWidget);

    // Verify presence of dropdown filters
    expect(find.byType(DropdownButton<String>), findsWidgets);

    // Verify presence of data table
    expect(find.byType(DataTable), findsOneWidget);

    // Verify presence of the Defaulter List button
    expect(find.text('Defaulter List'), findsOneWidget);
  });
}
