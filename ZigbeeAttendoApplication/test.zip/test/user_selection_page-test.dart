import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:aats_app/admin.dart';
import 'package:aats_app/user selection.dart';
import 'package:aats_app/student login.dart';
import 'package:aats_app/teacher login.dart';

void main() {
  group('WhoAreYouPage Tests', () {
    testWidgets('WhoAreYouPage UI loads correctly',
        (WidgetTester tester) async {
      // Build the WhoAreYouPage widget
      await tester.pumpWidget(MaterialApp(
        home: WhoAreYouPage(),
      ));

      // Wait for the page to settle
      await tester.pumpAndSettle();

      // Check if the title "SchoolSync" is displayed
      expect(find.text('SchoolSync'), findsOneWidget);

      // Check if the buttons for Teacher, Student, and Principal are displayed
      expect(find.text('Teacher'), findsOneWidget);
      expect(find.text('Student'), findsOneWidget);
      expect(find.text('Principal'), findsOneWidget);

      // Check if the icons are displayed next to the text
      expect(find.byIcon(Icons.school), findsOneWidget);
      expect(find.byIcon(Icons.person), findsOneWidget);
      expect(find.byIcon(Icons.admin_panel_settings), findsOneWidget);
    });

    testWidgets(
        'Navigating to Teacher Login page when Teacher button is pressed',
        (WidgetTester tester) async {
      // Create the widget for testing
      await tester.pumpWidget(MaterialApp(
        home: WhoAreYouPage(),
      ));

      // Wait for the page to settle
      await tester.pumpAndSettle();

      // Tap the Teacher button
      await tester.tap(find.text('Teacher'));
      await tester.pumpAndSettle();

      // Verify that we are navigating to the TeacherLoginPage
      expect(find.byType(TeacherLoginPage), findsOneWidget);
    });

    testWidgets(
        'Navigating to Student Login page when Student button is pressed',
        (WidgetTester tester) async {
      // Create the widget for testing
      await tester.pumpWidget(MaterialApp(
        home: WhoAreYouPage(),
      ));

      // Wait for the page to settle
      await tester.pumpAndSettle();

      // Tap the Student button
      await tester.tap(find.text('Student'));
      await tester.pumpAndSettle();

      // Verify that we are navigating to the StudentLoginPage
      expect(find.byType(StudentLoginPage), findsOneWidget);
    });

    testWidgets('Navigating to Admin page when Principal button is pressed',
        (WidgetTester tester) async {
      // Create the widget for testing
      await tester.pumpWidget(MaterialApp(
        home: WhoAreYouPage(),
      ));

      // Wait for the page to settle
      await tester.pumpAndSettle();

      // Tap the Principal button
      await tester.tap(find.text('Principal'));
      await tester.pumpAndSettle();

      // Verify that we are navigating to the Admin page (Attendance Pie Chart)
      expect(find.byType(AttendancePieChart), findsOneWidget);
    });
  });
}
