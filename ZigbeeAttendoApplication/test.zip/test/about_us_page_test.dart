import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:aats_app/About Us.dart';

void main() {
  testWidgets('About Us Page UI Test', (WidgetTester tester) async {
    // Build the AboutUsPage widget
    await tester.pumpWidget(MaterialApp(home: AboutUsPage()));

    // Verify the presence of key text elements
    expect(find.text('About Us'), findsOneWidget);
    expect(find.text('Company Name'), findsOneWidget);
    expect(find.text('Email'), findsOneWidget);
    expect(find.text('info@company.com'), findsOneWidget);
    expect(find.text('Phone Number'), findsOneWidget);
    expect(find.text('+1 234 567 890'), findsOneWidget);
    expect(find.text('Founder'), findsOneWidget);
    expect(find.text('John Doe'), findsOneWidget);
    expect(find.text('Office Address'), findsOneWidget);
    expect(find.text('123, Main Street, City, Country'), findsOneWidget);

    // Verify presence of icons
    expect(find.byIcon(Icons.email), findsOneWidget);
    expect(find.byIcon(Icons.phone), findsOneWidget);
    expect(find.byIcon(Icons.person), findsOneWidget);
    expect(find.byIcon(Icons.location_on), findsOneWidget);
  });
}
