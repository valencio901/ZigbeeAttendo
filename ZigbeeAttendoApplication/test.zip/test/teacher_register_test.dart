import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:mockito/mockito.dart';
import 'package:aats_app/teacher register page.dart';

// Mock class for HTTP client
class MockClient extends Mock implements http.Client {}

void main() {
  group('TeacherRegisterPage Tests', () {
    late MockClient mockClient;
    late TeacherRegisterPage teacherRegisterPage;

    setUp(() {
      mockClient = MockClient();
      teacherRegisterPage = const TeacherRegisterPage();
    });

    testWidgets('Initial state of TeacherRegisterPage',
        (WidgetTester tester) async {
      // Build the widget
      await tester.pumpWidget(MaterialApp(home: teacherRegisterPage));

      // Check if the form fields are present
      expect(find.text('Register'), findsOneWidget);
      expect(find.byType(TextField),
          findsNWidgets(4)); // For name, phone, address, password
      expect(find.byType(ElevatedButton), findsOneWidget); // Register button
    });

    testWidgets('Register with empty fields shows error',
        (WidgetTester tester) async {
      // Build the widget
      await tester.pumpWidget(MaterialApp(home: teacherRegisterPage));

      // Tap the register button
      await tester.tap(find.byType(ElevatedButton));
      await tester.pump();

      // Check if the error message is displayed (assuming it should display an error for empty fields)
      // Adjust depending on how your app handles validation
      expect(find.text('Please enter all fields'), findsOneWidget);
    });

    testWidgets('Register with valid data and successful response',
        (WidgetTester tester) async {
      // Simulate input
      final nameField = find.byType(TextField).first;
      final phoneField = find.byType(TextField).at(1);
      final addressField = find.byType(TextField).at(2);
      final passwordField = find.byType(TextField).at(3);

      await tester.pumpWidget(MaterialApp(home: teacherRegisterPage));

      // Enter valid data
      await tester.enterText(nameField, 'John Doe');
      await tester.enterText(phoneField, '1234567890');
      await tester.enterText(addressField, '123 Main St');
      await tester.enterText(passwordField, 'password123');

      // Mock the server response
      when(mockClient.post(
        Uri.parse('https://example.com/register_teacher.php'),
        body: anyNamed('body'),
      )).thenAnswer((_) async => http.Response('{"status": "success"}', 200));

      // Tap the register button
      await tester.tap(find.byType(ElevatedButton));
      await tester.pump();

      // Check if the success message or next screen is shown
      expect(find.text('Teacher registration successful'),
          findsOneWidget); // Assuming you show a success message
    });

    testWidgets('Register with invalid data shows error',
        (WidgetTester tester) async {
      // Simulate input
      final nameField = find.byType(TextField).first;
      final phoneField = find.byType(TextField).at(1);
      final addressField = find.byType(TextField).at(2);
      final passwordField = find.byType(TextField).at(3);

      await tester.pumpWidget(MaterialApp(home: teacherRegisterPage));

      // Enter invalid data
      await tester.enterText(nameField, 'John Doe');
      await tester.enterText(
          phoneField, 'invalidPhone'); // Invalid phone number
      await tester.enterText(addressField, '123 Main St');
      await tester.enterText(passwordField, 'password123');

      // Mock the server response with an error
      when(mockClient.post(
        Uri.parse('https://example.com/register_teacher.php'),
        body: anyNamed('body'),
      )).thenAnswer((_) async => http.Response(
          '{"status": "error", "message": "Invalid phone number"}', 200));

      // Tap the register button
      await tester.tap(find.byType(ElevatedButton));
      await tester.pump();

      // Check if the error message is displayed
      expect(find.text('Invalid phone number'), findsOneWidget);
    });

    testWidgets('Register network error shows error message',
        (WidgetTester tester) async {
      // Simulate input
      final nameField = find.byType(TextField).first;
      final phoneField = find.byType(TextField).at(1);
      final addressField = find.byType(TextField).at(2);
      final passwordField = find.byType(TextField).at(3);

      await tester.pumpWidget(MaterialApp(home: teacherRegisterPage));

      // Enter valid data
      await tester.enterText(nameField, 'John Doe');
      await tester.enterText(phoneField, '1234567890');
      await tester.enterText(addressField, '123 Main St');
      await tester.enterText(passwordField, 'password123');

      // Mock a network error (e.g., server not reachable)
      when(mockClient.post(
        Uri.parse('https://example.com/register_teacher.php'),
        body: anyNamed('body'),
      )).thenThrow(Exception('Network error'));

      // Tap the register button
      await tester.tap(find.byType(ElevatedButton));
      await tester.pump();

      // Check if the network error message is shown
      expect(find.text('An error occurred. Please try again later.'),
          findsOneWidget);
    });
  });
}
